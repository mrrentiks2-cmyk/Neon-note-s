package com.neondrift.notes;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Редактор заметки: живая разметка, чек-листы, вложения, напоминания, сейф. */
public class NoteActivity extends Base {
    static final String ACTION_NEW = "com.neondrift.notes.NEW_NOTE";
    static final String ACTION_LIST = "com.neondrift.notes.NEW_LIST";
    static final String ACTION_DRAW = "com.neondrift.notes.NEW_DRAW";
    static final String ACTION_VOICE = "com.neondrift.notes.NEW_VOICE";

    private static final int REQ_IMAGE = 1, REQ_CAMERA = 2, REQ_SKETCH = 3, REQ_EXPORT = 4, REQ_MIC = 5, REQ_NOTIF = 6, REQ_SKETCH_EDIT = 7;
    private static final ExecutorService SAVE = Executors.newSingleThreadExecutor();

    private Store store;
    private Note note;
    private boolean readOnly, dirty, discarded, preview, loaded, fromOutside;
    private List<Store.Att> atts = new ArrayList<>();

    private FrameLayout root;
    private LinearLayout page, attBox, audioBox, toolbar, trashBar;
    private android.view.ViewGroup metaRow;
    private HorizontalScrollView toolScroll;
    private ScrollView scroll;
    private EditText title, body;
    private TextView previewView, footer;
    private ImageView pinBtn, bellBtn, eyeBtn;
    private SidePanel panel;
    private PinPad pin;

    private final ArrayList<Styler.Applied> spans = new ArrayList<>();
    private String pristine; // текст, подставленный в новую заметку автоматически
    private final History bodyHistory = new History(), titleHistory = new History();
    private boolean applying, joinNext;
    private EditText lastFocus;
    private final Runnable highlightRun = this::highlight;
    private final Runnable saveRun = () -> save(false);

    // запись голоса
    private MediaRecorder recorder;
    private File recFile;
    private long recStart, recPausedAt, recPausedTotal;
    private View recPanel;
    private TextView recTime;
    private LevelView recLevel;
    private boolean recPaused;
    private String pendingKind;

    // воспроизведение
    private MediaPlayer player;
    private long playingId;
    private SeekBar playingBar;
    private TextView playingTime;
    private ImageView playingBtn;
    private final Runnable progressRun = new Runnable() {
        @Override
        public void run() {
            if (player == null) return;
            try {
                if (playingBar != null) {
                    playingBar.setMax(Math.max(1, player.getDuration()));
                    playingBar.setProgress(player.getCurrentPosition());
                }
                if (playingTime != null) playingTime.setText(Fmt.duration(player.getCurrentPosition()) + " / " + Fmt.duration(player.getDuration()));
            } catch (IllegalStateException ignored) {
            }
            root.postDelayed(this, 200);
        }
    };

    private Uri cameraUri;
    private long editingDrawing;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        store = Store.get(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        buildUi();
        if (saved != null) {
            String cam = saved.getString("cameraUri");
            if (cam != null) cameraUri = Uri.parse(cam);
            editingDrawing = saved.getLong("editingDrawing");
        }
        load(getIntent(), saved);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        save(false);
        out.putLong("noteId", note != null ? note.id : 0);
        if (cameraUri != null) out.putString("cameraUri", cameraUri.toString());
        out.putLong("editingDrawing", editingDrawing);
    }

    // ================================================================== загрузка

    private void load(Intent in, Bundle saved) {
        long id = saved != null ? saved.getLong("noteId") : 0;
        if (id == 0) id = in.getLongExtra("id", 0);
        String action = in.getAction();
        fromOutside = action != null && !Intent.ACTION_MAIN.equals(action) || in.getBooleanExtra("outside", false);
        if (id > 0) {
            note = store.get(id);
            if (note == null) {
                toast("Заметка не найдена");
                finish();
                return;
            }
        } else {
            note = new Note();
            note.folder = in.getLongExtra("folder", 0);
            note.locked = in.getBooleanExtra("vault", false) && Lock.isOpen();
            note.color = 0;
        }
        if (note.locked) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
            if (!Lock.isOpen()) {
                askVault();
                return;
            }
        }
        show();
        if (id == 0 && saved == null) startNew(in);
    }

    private void askVault() {
        page.setVisibility(View.INVISIBLE);
        pin.ask("Заметка в сейфе", "Введите PIN-код", p -> Lock.unlock(this, p), () -> {
            page.setVisibility(View.VISIBLE);
            show();
        }, this::finish);
        if (Bio.enabled(this)) {
            Runnable bio = () -> Bio.unlock(this, pin::success, () -> {});
            pin.setBio(bio);
            bio.run();
        }
    }

    /** Показать содержимое заметки. */
    private void show() {
        if (note.locked && !Lock.open(note)) {
            if (note.id > 0 && Lock.isOpen()) {
                toast("Не удалось расшифровать заметку");
                finish();
            }
            return;
        }
        applying = true;
        title.setText(note.shownTitle());
        body.setText(note.shownBody());
        applying = false;
        bodyHistory.clear();
        titleHistory.clear();
        readOnly = note.trashed > 0;
        title.setEnabled(!readOnly);
        body.setEnabled(!readOnly);
        trashBar.setVisibility(readOnly ? View.VISIBLE : View.GONE);
        loaded = true;
        dirty = false;
        if (note.id > 0) atts = store.attachments(note.id);
        applyColor();
        highlight();
        updateTop();
        updateMeta();
        renderAttachments();
        setPreview(readOnly || (note.id > 0 && prefs.openPreview() && !note.shownBody().isEmpty()));
    }

    /** Новая заметка: список, рисунок, голос, фото, «Поделиться» из других приложений. */
    private void startNew(Intent in) {
        String kind = in.getStringExtra("kind");
        String action = in.getAction();
        if (ACTION_LIST.equals(action)) kind = "list";
        else if (ACTION_DRAW.equals(action)) kind = "draw";
        else if (ACTION_VOICE.equals(action)) kind = "voice";
        String tag = in.getStringExtra("tag");
        if (Intent.ACTION_SEND.equals(action) || Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            String subject = in.getStringExtra(Intent.EXTRA_SUBJECT);
            CharSequence text = in.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (subject != null) title.setText(subject);
            if (text != null) body.setText(text.toString());
            ArrayList<Uri> images = new ArrayList<>();
            if (Intent.ACTION_SEND.equals(action)) {
                Uri u = in.getParcelableExtra(Intent.EXTRA_STREAM);
                if (u != null) images.add(u);
            } else {
                ArrayList<Uri> l = in.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                if (l != null) images.addAll(l);
            }
            if (!images.isEmpty()) addImages(images);
            dirty = true;
            save(false);
            return;
        }
        if (tag != null) {
            body.setText("\n\n#" + tag);
            body.setSelection(0);
        }
        if ("list".equals(kind)) {
            body.setText("- [ ] " + body.getText());
            body.setSelection(6);
        }
        pristine = text();
        dirty = false;
        bodyHistory.clear();
        if (kind == null || "text".equals(kind) || "list".equals(kind)) focusAndShow(body);
        if ("draw".equals(kind)) startActivityForResult(new Intent(this, SketchActivity.class), REQ_SKETCH);
        else if ("voice".equals(kind)) startRecording();
        else if ("photo".equals(kind)) pickImage();
    }

    private void focusAndShow(EditText e) {
        e.requestFocus();
        e.postDelayed(() -> ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(e, InputMethodManager.SHOW_IMPLICIT), 120);
    }

    // ================================================================== интерфейс

    private void buildUi() {
        root = new FrameLayout(this);
        page = ui.col();

        LinearLayout top = ui.row();
        top.setPadding(ui.dp(4), ui.dp(8), ui.dp(4), ui.dp(2));
        top.addView(ui.iconButton("back", Theme.TEXT, 46, 12, v -> onBackPressed()));
        top.addView(new View(this), Ui.lp(0, 1, 1f));
        pinBtn = ui.iconButton("pin", Theme.TEXT, 44, 11, v -> togglePin());
        top.addView(pinBtn);
        bellBtn = ui.iconButton("bell", Theme.TEXT, 44, 11, v -> reminderPanel());
        top.addView(bellBtn);
        top.addView(ui.iconButton("palette", Theme.TEXT, 44, 11, v -> colorPanel()));
        eyeBtn = ui.iconButton("eye", Theme.TEXT, 44, 11, v -> setPreview(!preview));
        top.addView(eyeBtn);
        top.addView(ui.iconButton("more", Theme.TEXT, 44, 11, v -> morePanel()));
        page.addView(top);

        trashBar = ui.row();
        trashBar.setPadding(ui.dp(18), ui.dp(8), ui.dp(8), ui.dp(8));
        trashBar.setBackground(Ui.round(Theme.alpha(0xFFFF5C7A, 40), ui.dp(14)));
        trashBar.addView(ui.text("Заметка в корзине — изменить её нельзя", 13.5f, Theme.TEXT, false), Ui.lp(0, Ui.WRAP, 1f));
        TextView restore = ui.text("ВОССТАНОВИТЬ", 13, Theme.ACCENT, true);
        restore.setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(10));
        restore.setOnClickListener(v -> {
            store.restore(new long[]{note.id});
            note.trashed = 0;
            Reminders.schedule(this, note);
            show();
            toast("Заметка восстановлена");
        });
        trashBar.addView(restore);
        trashBar.setVisibility(View.GONE);
        page.addView(trashBar, Ui.margins(Ui.MATCH, Ui.WRAP, ui.dp(14), ui.dp(4), ui.dp(14), ui.dp(4)));

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout col = ui.col();
        col.setPadding(ui.dp(20), ui.dp(4), ui.dp(20), ui.dp(24));

        attBox = ui.col();
        col.addView(attBox, Ui.lp(Ui.MATCH, Ui.WRAP));

        title = new EditText(this);
        title.setHint("Заголовок");
        title.setTextSize(23);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        title.setTextColor(Theme.TEXT);
        title.setHintTextColor(Theme.alpha(Theme.MUTED, 160));
        title.setBackground(null);
        title.setPadding(0, ui.dp(8), 0, ui.dp(4));
        // одна логическая строка с переносом: Enter на клавиатуре переводит к тексту
        title.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        title.setHorizontallyScrolling(false);
        title.setMaxLines(6);
        title.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_NEXT);
        title.setOnEditorActionListener((v, id, ev) -> {
            body.requestFocus();
            body.setSelection(0);
            return true;
        });
        title.setOnKeyListener((v, code, ev) -> {
            if (code == KeyEvent.KEYCODE_ENTER && ev.getAction() == KeyEvent.ACTION_DOWN) {
                body.requestFocus();
                body.setSelection(0);
                return true;
            }
            return false;
        });
        watch(title, titleHistory, false);
        col.addView(title, Ui.lp(Ui.MATCH, Ui.WRAP));

        metaRow = new MainActivity.FlowRow(this, ui.dp(8));
        col.addView(metaRow, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(2), 0, ui.dp(4)));

        body = new EditText(this) {
            @Override
            public boolean onTextContextMenuItem(int id) {
                // вставка без чужого оформления
                if (id == android.R.id.paste) id = android.R.id.pasteAsPlainText;
                return super.onTextContextMenuItem(id);
            }
        };
        body.setHint("Заметка");
        body.setTextSize(prefs.textSize());
        body.setTextColor(Theme.TEXT);
        body.setHintTextColor(Theme.alpha(Theme.MUTED, 160));
        body.setLineSpacing(0, 1.28f);
        body.setBackground(null);
        body.setGravity(Gravity.TOP | Gravity.START);
        body.setPadding(0, ui.dp(6), 0, ui.dp(60));
        body.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        body.setHorizontallyScrolling(false);
        body.setMinHeight(ui.dp(260));
        watch(body, bodyHistory, true);
        body.setOnTouchListener(new CheckTouch());
        col.addView(body, Ui.lp(Ui.MATCH, Ui.WRAP));

        previewView = ui.text("", prefs.textSize(), Theme.TEXT, false);
        previewView.setLineSpacing(0, 1.32f);
        previewView.setPadding(0, ui.dp(6), 0, ui.dp(60));
        previewView.setLinkTextColor(Theme.ACCENT2);
        previewView.setTextIsSelectable(false);
        previewView.setMinHeight(ui.dp(260));
        previewView.setVisibility(View.GONE);
        // двойное нажатие по тексту в режиме чтения — перейти к редактированию
        android.view.GestureDetector gd = new android.view.GestureDetector(this, new android.view.GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (readOnly) return false;
                setPreview(false);
                body.setSelection(body.length());
                focusAndShow(body);
                return true;
            }
        });
        previewView.setOnTouchListener((v, ev) -> {
            gd.onTouchEvent(ev);
            return false;
        });
        col.addView(previewView, Ui.lp(Ui.MATCH, Ui.WRAP));

        audioBox = ui.col();
        col.addView(audioBox, Ui.lp(Ui.MATCH, Ui.WRAP));
        footer = ui.text("", 12, Theme.MUTED, false);
        footer.setGravity(Gravity.CENTER);
        col.addView(footer, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(16), 0, 0));

        scroll.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        page.addView(scroll, Ui.lp(Ui.MATCH, 0, 1f));

        toolScroll = new HorizontalScrollView(this);
        toolScroll.setHorizontalScrollBarEnabled(false);
        toolbar = ui.row();
        toolbar.setPadding(ui.dp(6), ui.dp(4), ui.dp(6), ui.dp(4));
        tool("undo", "Отменить", this::undo);
        tool("redo", "Повторить", this::redo);
        sep();
        tool("checkbox", "Чек-лист", () -> linePrefix(EditOps.P_CHECK));
        tool("listBullet", "Список", () -> linePrefix(EditOps.P_BULLET));
        tool("listNumber", "Нумерованный список", () -> linePrefix(EditOps.P_NUMBER));
        tool("outdent", "Уменьшить отступ", () -> indent(false));
        tool("indent", "Увеличить отступ", () -> indent(true));
        sep();
        tool("heading", "Заголовок", () -> op(EditOps.heading(text(), selStart(), selEnd())));
        tool("bold", "Жирный", () -> wrap("**"));
        tool("italic", "Курсив", () -> wrap("_"));
        tool("strike", "Зачёркнутый", () -> wrap("~~"));
        tool("marker", "Выделение", () -> wrap("=="));
        tool("code", "Код", () -> wrap("`"));
        tool("quote", "Цитата", () -> linePrefix(EditOps.P_QUOTE));
        tool("divider", "Разделитель", () -> op(EditOps.divider(text(), selStart(), selEnd())));
        tool("clock", "Дата и время", () -> op(EditOps.insert(text(), selStart(), selEnd(), Fmt.full(System.currentTimeMillis(), 0))));
        sep();
        tool("image", "Картинка из галереи", this::pickImage);
        tool("camera", "Снять фото", this::takePhoto);
        tool("brush", "Рисунок", () -> startActivityForResult(new Intent(this, SketchActivity.class), REQ_SKETCH));
        tool("mic", "Записать голос", this::startRecording);
        toolScroll.addView(toolbar);
        toolScroll.setBackground(Ui.round(Theme.alpha(0xFF000000, 70), 0));
        page.addView(toolScroll, Ui.lp(Ui.MATCH, Ui.WRAP));

        root.addView(page, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        panel = new SidePanel(this, ui);
        root.addView(panel, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        pin = new PinPad(this, ui);
        root.addView(pin, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        setContentView(root);

        View.OnFocusChangeListener fl = (v, has) -> {
            if (has) lastFocus = (EditText) v;
        };
        title.setOnFocusChangeListener(fl);
        body.setOnFocusChangeListener(fl);
        lastFocus = body;
    }

    private void tool(String icon, String label, Runnable r) {
        ImageView b = ui.iconButton(icon, Theme.TEXT, 44, 11, v -> {
            if (readOnly) return;
            r.run();
        });
        b.setContentDescription(label);
        b.setOnLongClickListener(v -> {
            toast(label);
            return true;
        });
        toolbar.addView(b);
    }

    private void sep() {
        View s = new View(this);
        s.setBackgroundColor(Theme.alpha(Theme.TEXT, 30));
        toolbar.addView(s, Ui.margins(ui.dp(1), ui.dp(22), ui.dp(4), 0, ui.dp(4), 0));
    }

    private void applyColor() {
        int fill = note.color == 0 ? Theme.BG : Theme.mix(Theme.BG, Note.fill(note.color), 0.85f);
        root.setBackgroundColor(fill);
        getWindow().setStatusBarColor(fill);
        getWindow().setNavigationBarColor(fill);
    }

    private void updateTop() {
        pinBtn.setImageDrawable(new Glyph(note.pinned ? "pinFill" : "pin", note.pinned ? Theme.ACCENT : Theme.TEXT));
        bellBtn.setImageDrawable(new Glyph("bell", note.reminder > 0 && !note.fired ? Theme.ACCENT : Theme.TEXT));
        eyeBtn.setImageDrawable(new Glyph(preview ? "edit" : "eye", Theme.TEXT));
        eyeBtn.setContentDescription(preview ? "Редактировать" : "Режим чтения");
        pinBtn.setVisibility(readOnly ? View.GONE : View.VISIBLE);
        bellBtn.setVisibility(readOnly ? View.GONE : View.VISIBLE);
        eyeBtn.setVisibility(readOnly ? View.GONE : View.VISIBLE);
        toolScroll.setVisibility(readOnly || preview ? View.GONE : View.VISIBLE);
    }

    /** Чипы под заголовком: папка, напоминание, сейф. */
    private void updateMeta() {
        metaRow.removeAllViews();
        long now = System.currentTimeMillis();
        if (note.locked) metaRow.addView(metaChip("lock", "В сейфе", Theme.ACCENT, null));
        if (note.reminder > 0) {
            boolean past = note.fired || note.reminder < now;
            String text = Fmt.reminder(note.reminder, now) + (note.repeat != Repeat.NONE ? " · " + Repeat.NAMES[note.repeat].toLowerCase() : "");
            TextView c = metaChip(note.repeat != Repeat.NONE ? "repeat" : "bell", text, past ? Theme.MUTED : Theme.TEXT, readOnly ? null : this::reminderPanel);
            if (past) c.setPaintFlags(c.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
            metaRow.addView(c);
        }
        if (note.folder > 0) {
            Store.Folder f = store.folder(note.folder);
            if (f != null) metaRow.addView(metaChip("folder", f.name, Note.neon(f.color), readOnly ? null : this::folderPanel));
        }
        if (note.archived) metaRow.addView(metaChip("archive", "В архиве", Theme.MUTED, null));
        metaRow.setVisibility(metaRow.getChildCount() > 0 ? View.VISIBLE : View.GONE);
        updateFooter();
    }

    private void updateFooter() {
        long now = System.currentTimeMillis();
        String text = body.getText().toString();
        int words = Md.words(text);
        int[] p = Md.progress(text);
        StringBuilder sb = new StringBuilder();
        if (note.edited > 0) sb.append("Изменено ").append(Fmt.full(note.edited, now).toLowerCase().replace("сегодня, ", "сегодня в "));
        if (words > 0) sb.append(sb.length() > 0 ? " · " : "").append(Fmt.count(words, "слово", "слова", "слов"));
        if (p[1] > 0) sb.append(" · ").append(p[0]).append(" из ").append(p[1]);
        footer.setText(sb);
    }

    private TextView metaChip(String icon, String text, int color, Runnable click) {
        TextView t = ui.oneLine(text, 12.5f, color, false);
        t.setPadding(ui.dp(9), ui.dp(6), ui.dp(11), ui.dp(6));
        t.setBackground(Ui.ripple(Ui.round(0x1FFFFFFF, ui.dp(12)), Ui.round(0xFFFFFFFF, ui.dp(12))));
        Glyph g = new Glyph(icon, color);
        g.setBounds(0, 0, ui.dp(15), ui.dp(15));
        t.setCompoundDrawablesRelative(g, null, null, null);
        t.setCompoundDrawablePadding(ui.dp(6));
        if (click != null) t.setOnClickListener(v -> click.run());
        return t;
    }

    // ================================================================== правки текста

    /** Слежение за правками: история отмены, продолжение списков, Backspace по маркеру. */
    private void watch(EditText e, History h, boolean isBody) {
        e.addTextChangedListener(new TextWatcher() {
            int start, strip = -1, stripEnd;
            String before = "", after = "";

            @Override
            public void beforeTextChanged(CharSequence s, int st, int count, int aft) {
                if (applying) return;
                start = st;
                before = s.subSequence(st, st + count).toString();
                strip = -1;
                if (isBody && count == 1 && aft == 0 && !joinNext) {
                    int[] r = EditOps.markerRange(s.toString(), st);
                    if (r != null && st == r[1] - 1 && r[1] - r[0] > 1) {
                        strip = r[0];
                        stripEnd = r[1] - 1;
                    }
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int st, int b, int count) {
                if (applying) return;
                after = s.subSequence(st, st + count).toString();
            }

            @Override
            public void afterTextChanged(Editable ed) {
                if (applying) return;
                h.record(start, before, after, System.currentTimeMillis(), joinNext);
                boolean wasJoin = joinNext;
                joinNext = false;
                changed();
                if (!isBody || wasJoin) return;
                if (after.equals("\n") && before.isEmpty()) {
                    int st = start;
                    body.post(() -> {
                        // считаем заново по текущему тексту: между нажатием и этим моментом мог прийти ещё символ
                        if (st >= body.length() || body.getText().charAt(st) != '\n') return;
                        EditOps.Result r = EditOps.afterNewline(text(), st);
                        if (r != null) op(r, true);
                    });
                } else if (strip >= 0) {
                    int a = strip, b = stripEnd;
                    body.post(() -> {
                        if (b <= body.length()) {
                            joinNext = true;
                            body.getText().delete(a, b);
                            body.setSelection(a);
                        }
                    });
                }
            }
        });
    }

    private void changed() {
        if (!loaded) return;
        dirty = true;
        root.removeCallbacks(highlightRun);
        root.postDelayed(highlightRun, body.length() > 20000 ? 250 : 60);
        root.removeCallbacks(saveRun);
        root.postDelayed(saveRun, 1500);
    }

    private void highlight() {
        Styler.editor(body.getText(), spans, Theme.TEXT);
        if (preview) renderPreview();
    }

    private String text() {
        return body.getText().toString();
    }

    private int selStart() {
        return Math.max(0, Math.min(body.getSelectionStart(), body.getSelectionEnd()));
    }

    private int selEnd() {
        return Math.max(0, Math.max(body.getSelectionStart(), body.getSelectionEnd()));
    }

    private void ensureBodyFocus() {
        if (preview) setPreview(false);
        if (!body.hasFocus()) {
            body.requestFocus();
            if (lastFocus == title) body.setSelection(body.length());
        }
    }

    private void wrap(String mk) {
        ensureBodyFocus();
        op(EditOps.wrap(text(), selStart(), selEnd(), mk));
    }

    private void linePrefix(int kind) {
        ensureBodyFocus();
        op(EditOps.prefix(text(), selStart(), selEnd(), kind));
    }

    private void indent(boolean in) {
        ensureBodyFocus();
        op(EditOps.indent(text(), selStart(), selEnd(), in));
    }

    private void op(EditOps.Result r) {
        op(r, false);
    }

    /** Применить результат операции минимальной заменой (чтобы не сбивать прокрутку и стили). */
    private void op(EditOps.Result r, boolean join) {
        Editable e = body.getText();
        String old = e.toString(), nw = r.text;
        int p = 0, ol = old.length(), nl = nw.length();
        while (p < ol && p < nl && old.charAt(p) == nw.charAt(p)) p++;
        int s = 0;
        while (s < ol - p && s < nl - p && old.charAt(ol - 1 - s) == nw.charAt(nl - 1 - s)) s++;
        if (p != ol - s || p != nl - s) {
            joinNext = join;
            e.replace(p, ol - s, nw.substring(p, nl - s));
            joinNext = false;
        }
        body.setSelection(Math.min(r.start, body.length()), Math.min(r.end, body.length()));
        root.removeCallbacks(highlightRun);
        highlight();
    }

    private void undo() {
        EditText target = lastFocus == title ? title : body;
        History h = target == title ? titleHistory : bodyHistory;
        if (!h.canUndo()) {
            toast("Отменять нечего");
            return;
        }
        applying = true;
        int cur = 0;
        for (History.Edit ed : h.undo()) {
            Editable e = target.getText();
            int end = Math.min(e.length(), ed.start + ed.after.length());
            e.replace(Math.min(ed.start, e.length()), end, ed.before);
            cur = ed.start + ed.before.length();
        }
        applying = false;
        target.setSelection(Math.min(cur, target.length()));
        changed();
        if (target == body) highlight();
    }

    private void redo() {
        EditText target = lastFocus == title ? title : body;
        History h = target == title ? titleHistory : bodyHistory;
        if (!h.canRedo()) {
            toast("Повторять нечего");
            return;
        }
        applying = true;
        int cur = 0;
        ArrayList<History.Edit> list = h.redo();
        for (int i = list.size() - 1; i >= 0; i--) {
            History.Edit ed = list.get(i);
            Editable e = target.getText();
            int end = Math.min(e.length(), ed.start + ed.before.length());
            e.replace(Math.min(ed.start, e.length()), end, ed.after);
            cur = ed.start + ed.after.length();
        }
        applying = false;
        target.setSelection(Math.min(cur, target.length()));
        changed();
        if (target == body) highlight();
    }

    /** Отметить пункт строки line; если включено — выполненные уезжают вниз списка. */
    private void toggleLine(int line) {
        if (readOnly) return;
        String t = text();
        String nt = Md.toggleCheck(t, line);
        if (nt.equals(t)) return;
        int sel = selStart();
        if (prefs.checkedToBottom()) nt = Md.sortChecked(nt);
        op(new EditOps.Result(nt, Math.min(sel, nt.length()), Math.min(sel, nt.length())));
        body.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
    }

    /** Нажатие на нарисованную галочку в редакторе отмечает пункт и не двигает курсор. */
    private final class CheckTouch implements View.OnTouchListener {
        int line = -1;
        float dx, dy;

        @Override
        public boolean onTouch(View v, MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    line = hit(ev.getX(), ev.getY());
                    dx = ev.getX();
                    dy = ev.getY();
                    return line >= 0;
                case MotionEvent.ACTION_MOVE:
                    if (line >= 0) {
                        int slop = ViewConfiguration.get(NoteActivity.this).getScaledTouchSlop();
                        if (Math.abs(ev.getX() - dx) > slop || Math.abs(ev.getY() - dy) > slop) line = -1;
                        return true;
                    }
                    return false;
                case MotionEvent.ACTION_UP:
                    if (line >= 0) {
                        int l = line;
                        line = -1;
                        toggleLine(l);
                        return true;
                    }
                    return false;
                case MotionEvent.ACTION_CANCEL:
                    boolean was = line >= 0;
                    line = -1;
                    return was;
                default:
                    return line >= 0;
            }
        }

        private int hit(float x, float y) {
            Layout layout = body.getLayout();
            if (layout == null || readOnly) return -1;
            int off = body.getOffsetForPosition(x, y);
            if (off < 0) return -1;
            String t = text();
            int ln = EditOps.checkAt(t, off);
            if (ln < 0) return -1;
            int ls = EditOps.lineStart(t, off);
            java.util.regex.Matcher m = Md.CHECK_LINE.matcher(t.substring(ls, EditOps.lineEnd(t, off)));
            if (!m.matches()) return -1;
            int bs = ls + m.start(2);
            float left = layout.getPrimaryHorizontal(bs) + body.getTotalPaddingLeft() - body.getScrollX();
            float right = layout.getPrimaryHorizontal(Math.min(t.length(), bs + 5)) + body.getTotalPaddingLeft() - body.getScrollX();
            if (right <= left) right = left + body.getTextSize() * 1.3f;
            float slop = ui.dp(10);
            int vline = layout.getLineForOffset(bs);
            float top = layout.getLineTop(vline) + body.getTotalPaddingTop() - body.getScrollY();
            float bottom = layout.getLineBottom(vline) + body.getTotalPaddingTop() - body.getScrollY();
            return x >= left - slop && x <= right + slop && y >= top - slop / 2 && y <= bottom + slop / 2 ? ln : -1;
        }
    }

    // ================================================================== режим чтения

    private void setPreview(boolean on) {
        preview = on;
        if (on) {
            hideKeyboard();
            renderPreview();
        }
        body.setVisibility(on ? View.GONE : View.VISIBLE);
        previewView.setVisibility(on ? View.VISIBLE : View.GONE);
        title.setFocusable(!on && !readOnly);
        title.setFocusableInTouchMode(!on && !readOnly);
        updateTop();
    }

    private void renderPreview() {
        String t = text();
        if (t.trim().isEmpty()) {
            previewView.setText(readOnly ? "" : "Пустая заметка. Дважды нажмите, чтобы писать.");
            previewView.setTextColor(Theme.MUTED);
            return;
        }
        previewView.setTextColor(Theme.TEXT);
        SpannableStringBuilder sb = Styler.rendered(Md.render(t), Theme.TEXT, readOnly ? null : this::toggleLine, tag -> {
            save(false);
            startActivity(new Intent(this, MainActivity.class).putExtra("tag", tag)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
            finish();
        });
        Linkify.addLinks(sb, Linkify.WEB_URLS | Linkify.EMAIL_ADDRESSES | Linkify.PHONE_NUMBERS);
        previewView.setText(sb);
        previewView.setMovementMethod(LinkMovementMethod.getInstance());
    }

    // ================================================================== сохранение

    private void save(boolean leaving) {
        if (!loaded || readOnly || discarded || note == null) return;
        if (note.locked && !Lock.isOpen()) return;
        root.removeCallbacks(saveRun);
        String t = title.getText().toString(), b = body.getText().toString();
        boolean empty = t.trim().isEmpty() && (blank(b) || b.equals(pristine)) && atts.isEmpty();
        long now = System.currentTimeMillis();
        if (note.id == 0) {
            if (empty) return;
            note.created = note.edited = now;
            fill(t, b);
            store.insert(note);
            dirty = false;
            NoteWidget.refreshAll(this);
            return;
        }
        if (empty && leaving) {
            Reminders.cancel(this, note.id);
            store.deleteForever(new long[]{note.id});
            discarded = true;
            toast("Пустая заметка удалена");
            NoteWidget.refreshAll(this);
            return;
        }
        if (!dirty) return;
        note.edited = now;
        fill(t, b);
        dirty = false;
        Note snapshot = note.copy();
        SAVE.execute(() -> {
            store.update(snapshot);
            NoteWidget.refresh(getApplicationContext(), snapshot.id);
        });
        updateFooter();
    }

    /** Только пустые пункты списков — считаем, что текста нет. */
    static boolean blank(String b) {
        return b.replaceAll("(?m)^\\s*([-*+] \\[[ xX]\\]|[-*+]|\\d{1,4}[.)]|>)?\\s*$", "").trim().isEmpty();
    }

    private void fill(String t, String b) {
        if (note.locked) Lock.seal(note, t, b);
        else {
            note.title = t;
            note.body = b;
        }
    }

    /** Заметка должна существовать в базе (для вложений). */
    private long ensureSaved() {
        if (note.id == 0) {
            note.created = note.edited = System.currentTimeMillis();
            fill(title.getText().toString(), body.getText().toString());
            store.insert(note);
        }
        return note.id;
    }

    /** Мгновенно записать поля заметки (не текст). */
    private void saveMeta() {
        if (note.id == 0) {
            if (title.length() == 0 && body.length() == 0 && atts.isEmpty()) {
                updateMeta();
                updateTop();
                return;
            }
            ensureSaved();
        }
        if (dirty) save(false);
        else {
            Note snapshot = note.copy();
            SAVE.execute(() -> store.update(snapshot));
        }
        updateMeta();
        updateTop();
        NoteWidget.refreshAll(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        save(isFinishing());
        if (player != null) pausePlayer();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (note != null && note.locked && loaded && !Lock.isOpen()) {
            // сейф закрылся, пока приложение было в фоне — прячем текст
            loaded = false;
            applying = true;
            title.setText("");
            body.setText("");
            applying = false;
            askVault();
        } else if (note != null && note.id > 0 && loaded) {
            atts = store.attachments(note.id);
            renderAttachments();
        }
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        root.postDelayed(this::renderAttachments, 120);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopPlayer();
        if (recorder != null) cancelRecording();
    }

    @Override
    public void onBackPressed() {
        if (pin.isShowing()) {
            pin.cancel();
            return;
        }
        if (panel.isOpen()) {
            panel.close();
            return;
        }
        if (recorder != null) {
            stopRecording(true);
            return;
        }
        save(true);
        if (fromOutside && isTaskRoot()) startActivity(new Intent(this, MainActivity.class));
        super.onBackPressed();
    }

    // ================================================================== верхние кнопки и панели

    private void togglePin() {
        note.pinned = !note.pinned;
        saveMeta();
        toast(note.pinned ? "Закреплено" : "Откреплено");
    }

    private void colorPanel() {
        LinearLayout box = panel.open("Цвет заметки");
        MainActivity.FlowRow row = new MainActivity.FlowRow(this, ui.dp(12));
        for (int i = 0; i < Note.FILL.length; i++) {
            int c = i;
            FrameLayout sw = new FrameLayout(this);
            View dot = new View(this);
            dot.setBackground(Ui.stroke(Note.fill(i), i == 0 ? Theme.MUTED : Note.neon(i), ui.dp(2), ui.dp(30)));
            sw.addView(dot, new FrameLayout.LayoutParams(ui.dp(46), ui.dp(46), Gravity.CENTER));
            if (i == note.color) {
                ImageView ck = new ImageView(this);
                ck.setImageDrawable(new Glyph("check", Theme.TEXT));
                sw.addView(ck, new FrameLayout.LayoutParams(ui.dp(22), ui.dp(22), Gravity.CENTER));
            }
            sw.setContentDescription(Note.COLOR_NAMES[i]);
            sw.setOnClickListener(v -> {
                note.color = c;
                applyColor();
                saveMeta();
                colorPanel();
            });
            row.addView(sw, new android.view.ViewGroup.LayoutParams(ui.dp(50), ui.dp(50)));
        }
        box.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(10), 0, 0));
        panel.note(box, Note.COLOR_NAMES[note.color]);
    }

    private void folderPanel() {
        LinearLayout box = panel.open("Папка");
        if (note.locked) {
            panel.note(box, "Заметки в сейфе хранятся отдельно от папок.");
            return;
        }
        panel.option(box, "Без папки", null, note.folder == 0, () -> {
            note.folder = 0;
            panel.close();
            saveMeta();
        });
        for (Store.Folder f : store.folders()) {
            panel.option(box, f.name, null, note.folder == f.id, () -> {
                note.folder = f.id;
                panel.close();
                saveMeta();
            });
        }
        panel.option(box, "+ Новая папка", null, false, () -> {
            panel.close();
            prompt("Новая папка", "", "Название", name -> {
                note.folder = store.addFolder(name, (store.folders().size() % (Note.NEON.length - 1)) + 1);
                saveMeta();
            });
        });
    }

    private void reminderPanel() {
        LinearLayout box = panel.open("Напоминание");
        long now = System.currentTimeMillis();
        int morning = prefs.morningHour();
        Calendar c = Calendar.getInstance();
        ArrayList<long[]> quick = new ArrayList<>();
        ArrayList<String> names = new ArrayList<>();
        c.setTimeInMillis(now);
        if (c.get(Calendar.HOUR_OF_DAY) < 17) {
            quick.add(new long[]{at(0, 18)});
            names.add("Сегодня вечером");
        }
        quick.add(new long[]{now + 3600_000L - now % 60_000});
        names.add("Через час");
        quick.add(new long[]{at(1, morning)});
        names.add("Завтра утром");
        c.setTimeInMillis(now);
        int toMonday = (Calendar.MONDAY - c.get(Calendar.DAY_OF_WEEK) + 7) % 7;
        if (toMonday == 0) toMonday = 7;
        if (toMonday > 1) {
            quick.add(new long[]{at(toMonday, morning)});
            names.add("В понедельник");
        }
        for (int i = 0; i < quick.size(); i++) {
            long when = quick.get(i)[0];
            panel.option(box, names.get(i), Fmt.reminder(when, now), false, () -> {
                panel.close();
                setReminder(when, note.repeat);
            });
        }
        panel.option(box, "Выбрать дату и время…", null, false, () -> {
            panel.close();
            pickDateTime();
        });
        panel.section(box, "ПОВТОР");
        LinearLayout chips = panel.chipRow(box);
        for (int r = 0; r < Repeat.NAMES.length; r++) {
            int rep = r;
            panel.chip(chips, Repeat.NAMES[r], note.repeat == r, () -> {
                note.repeat = rep;
                if (note.reminder > 0) {
                    if (note.reminder < System.currentTimeMillis() && rep != Repeat.NONE) {
                        note.reminder = Repeat.next(note.reminder, rep, System.currentTimeMillis());
                    }
                    note.fired = note.reminder < System.currentTimeMillis();
                    saveMeta();
                    Reminders.schedule(this, note);
                }
                reminderPanel();
            });
        }
        if (note.reminder > 0) {
            panel.section(box, "СЕЙЧАС");
            panel.option(box, "Удалить напоминание", Fmt.reminder(note.reminder, now), false, () -> {
                panel.close();
                note.reminder = 0;
                note.fired = false;
                Reminders.cancel(this, note.id);
                saveMeta();
            });
        }
        if (!Reminders.exact(this)) {
            panel.note(box, "Точные будильники запрещены в настройках системы — напоминание может прийти с опозданием на несколько минут.");
            panel.option(box, "Разрешить точное время", null, false, () -> {
                try {
                    startActivity(new Intent("android.settings.REQUEST_SCHEDULE_EXACT_ALARM", Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    toast("Откройте настройки приложения вручную");
                }
            });
        }
    }

    /** Время через days дней в hour:00. */
    private static long at(int days, int hour) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, days);
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private void pickDateTime() {
        Calendar c = Calendar.getInstance();
        if (note.reminder > System.currentTimeMillis()) c.setTimeInMillis(note.reminder);
        else {
            c.add(Calendar.HOUR_OF_DAY, 1);
            c.set(Calendar.MINUTE, 0);
        }
        int theme = android.R.style.Theme_DeviceDefault_Dialog_Alert;
        new DatePickerDialog(this, theme, (v, y, m, d) -> {
            new TimePickerDialog(this, theme, (tv, h, min) -> {
                Calendar r = Calendar.getInstance();
                r.set(y, m, d, h, min, 0);
                r.set(Calendar.MILLISECOND, 0);
                if (r.getTimeInMillis() < System.currentTimeMillis()) {
                    toast("Это время уже прошло");
                    return;
                }
                setReminder(r.getTimeInMillis(), note.repeat);
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void setReminder(long when, int repeat) {
        note.reminder = when;
        note.repeat = repeat;
        note.fired = false;
        ensureSaved();
        saveMeta();
        Reminders.schedule(this, note);
        toast("Напомню: " + Fmt.reminder(when, System.currentTimeMillis()));
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
    }

    private void morePanel() {
        LinearLayout box = panel.open("Заметка");
        if (readOnly) {
            panel.option(box, "Восстановить", null, false, () -> {
                panel.close();
                store.restore(new long[]{note.id});
                note.trashed = 0;
                show();
            });
            panel.option(box, "Удалить навсегда", "Вместе с вложениями", false, () -> {
                panel.close();
                confirm("Удалить навсегда?", "Восстановить будет нельзя.", "Удалить", () -> {
                    store.deleteForever(new long[]{note.id});
                    discarded = true;
                    finish();
                });
            });
            return;
        }
        String t = text();
        if (!note.locked) {
            Store.Folder f = note.folder > 0 ? store.folder(note.folder) : null;
            panel.option(box, "Папка", f != null ? f.name : "Без папки", false, () -> {
                panel.close();
                folderPanel();
            });
        }
        panel.option(box, Md.isChecklist(t) ? "Сделать обычным текстом" : "Сделать чек-листом", null, false, () -> {
            panel.close();
            setPreview(false);
            op(new EditOps.Result(Md.toggleChecklist(text()), 0, 0));
        });
        int[] p = Md.progress(t);
        if (p[1] > 0) {
            panel.section(box, "ЧЕК-ЛИСТ · " + p[0] + " ИЗ " + p[1]);
            if (p[0] > 0) {
                panel.option(box, "Выполненные — вниз", null, false, () -> {
                    panel.close();
                    op(new EditOps.Result(Md.sortChecked(text()), 0, 0));
                });
                panel.option(box, "Снять все галочки", null, false, () -> {
                    panel.close();
                    op(new EditOps.Result(text().replaceAll("(?m)^(\\s*[-*+] )\\[[xX]\\]", "$1[ ]"), 0, 0));
                });
                panel.option(box, "Удалить выполненные", null, false, () -> {
                    panel.close();
                    String nt = text().replaceAll("(?m)^\\s*[-*+] \\[[xX]\\].*(\\n|$)", "");
                    op(new EditOps.Result(nt.endsWith("\n") && !text().endsWith("\n") ? nt.substring(0, nt.length() - 1) : nt, 0, 0));
                });
            }
        }
        panel.section(box, "ДЕЙСТВИЯ");
        if (!note.locked) {
            panel.option(box, note.archived ? "Вернуть из архива" : "В архив", null, false, () -> {
                panel.close();
                note.archived = !note.archived;
                saveMeta();
                if (note.archived) {
                    toast("Заметка в архиве");
                    finish();
                }
            });
        }
        panel.option(box, note.locked ? "Достать из сейфа" : "Убрать в сейф", note.locked ? "Хранить без шифрования" : "Зашифровать текст и вложения", false, () -> {
            panel.close();
            if (note.locked) moveVault(false);
            else withVault(() -> moveVault(true));
        });
        panel.option(box, "Создать копию", null, false, () -> {
            panel.close();
            save(false);
            if (note.id == 0) return;
            long id = store.duplicate(note.id);
            startActivity(new Intent(this, NoteActivity.class).putExtra("id", id));
            finish();
        });
        if (!note.locked) {
            panel.option(box, "Поделиться", "Текстом в любое приложение", false, () -> {
                panel.close();
                share(false);
            });
            panel.option(box, "Отправить файлом .md", null, false, () -> {
                panel.close();
                share(true);
            });
        }
        panel.option(box, "Сохранить в файл", "Markdown (.md) в выбранную папку", false, () -> {
            panel.close();
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/markdown")
                    .putExtra(Intent.EXTRA_TITLE, Note.fileName(title.getText().toString(), "Заметка") + ".md");
            try {
                startActivityForResult(i, REQ_EXPORT);
            } catch (Exception e) {
                toast("Нет приложения для выбора папки");
            }
        });
        panel.option(box, "Информация", null, false, () -> {
            panel.close();
            info();
        });
        panel.option(box, "Удалить", "В корзину на 30 дней", false, () -> {
            panel.close();
            if (note.id > 0) {
                save(false);
                Reminders.cancel(this, note.id);
                store.trash(new long[]{note.id});
                NoteWidget.refreshAll(this);
                toast("Заметка в корзине");
            }
            discarded = true;
            finish();
        });
    }

    private void withVault(Runnable r) {
        if (Lock.isOpen()) {
            r.run();
            return;
        }
        if (!Lock.isSet(this)) {
            pin.create("Новый сейф", p -> Lock.setup(this, p), () -> {
                toast("Сейф создан");
                r.run();
            }, null);
            return;
        }
        pin.ask("Сейф", "Введите PIN-код", p -> Lock.unlock(this, p), r, null);
        if (Bio.enabled(this)) {
            Runnable bio = () -> Bio.unlock(this, pin::success, () -> {});
            pin.setBio(bio);
            bio.run();
        }
    }

    /** Убрать в сейф или достать из него, вместе с файлами. */
    private void moveVault(boolean to) {
        byte[] key = Lock.key();
        if (key == null) return;
        String t = title.getText().toString(), b = text();
        ensureSaved();
        stopPlayer();
        if (to) {
            note.locked = true;
            note.archived = false;
            note.folder = 0;
            Lock.seal(note, t, b);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        } else {
            note.locked = false;
            note.title = t;
            note.body = b;
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }
        dirty = false;
        store.update(note.copy()); // текст — сразу, чтобы следующие сохранения не обогнали
        List<Store.Att> list = new ArrayList<>(atts);
        Media.IO.execute(() -> {
            for (Store.Att a : list) if (to ? Media.seal(this, a, key) : Media.unseal(this, a, key)) store.updateAttachment(a);
            Media.MAIN.post(() -> {
                atts = store.attachments(note.id);
                renderAttachments();
                updateMeta();
                NoteWidget.refreshAll(this);
                toast(to ? "Заметка в сейфе" : "Заметка достана из сейфа");
            });
        });
    }

    private void share(boolean asFile) {
        String t = title.getText().toString().trim(), b = text();
        if (asFile) {
            try {
                File dir = Files.root(this, "share");
                File f = new File(dir, Note.fileName(t, "Заметка") + ".md");
                try (OutputStream out = new java.io.FileOutputStream(f)) {
                    out.write(((t.isEmpty() ? "" : "# " + t + "\n\n") + b).getBytes(StandardCharsets.UTF_8));
                }
                Uri u = Files.uri("share", f.getName());
                Intent s = new Intent(Intent.ACTION_SEND).setType("text/markdown").putExtra(Intent.EXTRA_STREAM, u)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                s.setClipData(ClipData.newRawUri(f.getName(), u));
                startActivity(Intent.createChooser(s, "Отправить файл"));
            } catch (Exception e) {
                toast("Не удалось подготовить файл");
            }
            return;
        }
        Intent s = new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, (t.isEmpty() ? "" : t + "\n\n") + Md.plain(b));
        if (!t.isEmpty()) s.putExtra(Intent.EXTRA_SUBJECT, t);
        startActivity(Intent.createChooser(s, "Поделиться"));
    }

    private void info() {
        long now = System.currentTimeMillis();
        String b = text();
        int[] p = Md.progress(b);
        StringBuilder sb = new StringBuilder();
        if (note.created > 0) sb.append("Создана: ").append(Fmt.full(note.created, now)).append('\n');
        if (note.edited > 0) sb.append("Изменена: ").append(Fmt.full(note.edited, now)).append('\n');
        sb.append("Слов: ").append(Md.words(b)).append(" · символов: ").append(b.length()).append('\n');
        if (p[1] > 0) sb.append("Пунктов: ").append(p[1]).append(", выполнено ").append(p[0]).append('\n');
        int img = 0, aud = 0;
        long size = 0, dur = 0;
        for (Store.Att a : atts) {
            if (a.kind == Store.AUDIO) {
                aud++;
                dur += a.duration;
            } else img++;
            size += Media.file(this, a).length();
        }
        if (img > 0) sb.append("Картинок и рисунков: ").append(img).append('\n');
        if (aud > 0) sb.append("Голосовых: ").append(aud).append(" (").append(Fmt.duration(dur)).append(")\n");
        if (size > 0) sb.append("Вложения занимают: ").append(Fmt.size(size)).append('\n');
        java.util.Set<String> tags = Md.tags(title.getText() + "\n" + b);
        if (!tags.isEmpty()) sb.append("Теги: #").append(String.join(" #", tags)).append('\n');
        if (note.locked) sb.append("\nЗашифрована AES-256 ключом от PIN-кода сейфа.");
        dialog().setTitle("Информация").setMessage(sb.toString().trim()).setPositiveButton("OK", null).show();
    }

    // ================================================================== вложения

    private void renderAttachments() {
        attBox.removeAllViews();
        audioBox.removeAllViews();
        ArrayList<Store.Att> visual = new ArrayList<>();
        for (Store.Att a : atts) {
            if (a.visual()) visual.add(a);
            else audioBox.addView(audioRow(a));
        }
        if (!visual.isEmpty()) {
            int width = getResources().getDisplayMetrics().widthPixels - ui.dp(40);
            if (visual.size() == 1) {
                Store.Att a = visual.get(0);
                int h = a.w > 0 ? Math.round(width * (a.h / (float) a.w)) : Math.round(width * 0.66f);
                h = Math.min(h, ui.dp(420));
                ImageView iv = imageView(a, visual);
                attBox.addView(iv, Ui.margins(Ui.MATCH, h, 0, ui.dp(6), 0, ui.dp(6)));
                Media.thumb(this, a, Math.min(width, ui.dp(900)), iv);
            } else {
                HorizontalScrollView hs = new HorizontalScrollView(this);
                hs.setHorizontalScrollBarEnabled(false);
                LinearLayout row = ui.row();
                int h = ui.dp(170);
                for (Store.Att a : visual) {
                    int w = a.w > 0 && a.h > 0 ? Math.round(h * (a.w / (float) a.h)) : h;
                    w = Math.max(ui.dp(100), Math.min(w, ui.dp(300)));
                    ImageView iv = imageView(a, visual);
                    LinearLayout.LayoutParams lp = Ui.lp(w, h);
                    lp.rightMargin = ui.dp(8);
                    row.addView(iv, lp);
                    Media.thumb(this, a, w, iv);
                }
                hs.addView(row);
                attBox.addView(hs, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(6), 0, ui.dp(6)));
            }
        }
        attBox.setVisibility(attBox.getChildCount() > 0 ? View.VISIBLE : View.GONE);
        audioBox.setVisibility(audioBox.getChildCount() > 0 ? View.VISIBLE : View.GONE);
    }

    private ImageView imageView(Store.Att a, List<Store.Att> all) {
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(Ui.round(Theme.SURFACE2, ui.dp(16)));
        iv.setClipToOutline(true);
        iv.setOutlineProvider(Ui.rounded(ui.dp(16)));
        iv.setOnClickListener(v -> {
            save(false);
            startActivity(new Intent(this, ViewerActivity.class).putExtra("note", note.id).putExtra("att", a.id));
        });
        iv.setOnLongClickListener(v -> {
            attMenu(a);
            return true;
        });
        iv.setContentDescription(a.kind == Store.DRAWING ? "Рисунок" : "Картинка");
        return iv;
    }

    private void attMenu(Store.Att a) {
        LinearLayout box = panel.open(a.kind == Store.AUDIO ? "Голосовая заметка" : a.kind == Store.DRAWING ? "Рисунок" : "Картинка");
        if (a.kind == Store.DRAWING && !readOnly) {
            panel.option(box, "Дорисовать", null, false, () -> {
                panel.close();
                File f = Media.plain(this, a);
                if (f == null) return;
                editingDrawing = a.id;
                startActivityForResult(new Intent(this, SketchActivity.class).putExtra("base", f.getPath()), REQ_SKETCH_EDIT);
            });
        }
        panel.option(box, "Поделиться", null, false, () -> {
            panel.close();
            Uri u = Files.uri(this, a);
            if (u == null) return;
            Intent s = new Intent(Intent.ACTION_SEND).setType(Files.type(a.file.replace(".nv", ""))).putExtra(Intent.EXTRA_STREAM, u)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            s.setClipData(ClipData.newRawUri("", u));
            startActivity(Intent.createChooser(s, "Поделиться"));
        });
        panel.option(box, "Открыть в другом приложении", null, false, () -> {
            panel.close();
            Uri u = Files.uri(this, a);
            if (u == null) return;
            Intent v = new Intent(Intent.ACTION_VIEW).setDataAndType(u, Files.type(a.file.replace(".nv", "")))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                startActivity(v);
            } catch (Exception e) {
                toast("Нет подходящего приложения");
            }
        });
        if (!readOnly) {
            panel.option(box, "Удалить", null, false, () -> {
                panel.close();
                if (playingId == a.id) stopPlayer();
                store.deleteAttachment(a);
                atts.remove(a);
                atts = store.attachments(note.id);
                renderAttachments();
                note.edited = System.currentTimeMillis();
                saveMeta();
            });
        }
    }

    private View audioRow(Store.Att a) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(6), ui.dp(6), ui.dp(4), ui.dp(6));
        row.setBackground(Ui.round(0x1AFFFFFF, ui.dp(18)));
        ImageView play = ui.iconButton("play", Theme.BG, 44, 12, null);
        play.setBackground(Ui.ripple(Ui.oval(Theme.ACCENT), Ui.oval(0xFFFFFFFF)));
        row.addView(play);
        LinearLayout mid = ui.col();
        SeekBar bar = new SeekBar(this);
        bar.setMax((int) Math.max(1, a.duration));
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(Theme.ACCENT));
        bar.setThumbTintList(android.content.res.ColorStateList.valueOf(Theme.ACCENT));
        bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0x55FFFFFF));
        mid.addView(bar, Ui.lp(Ui.MATCH, ui.dp(28)));
        TextView time = ui.text(Fmt.duration(a.duration), 12, Theme.MUTED, false);
        time.setPadding(ui.dp(16), 0, 0, 0);
        mid.addView(time);
        row.addView(mid, Ui.lp(0, Ui.WRAP, 1f));
        row.addView(ui.iconButton("more", Theme.MUTED, 40, 10, v -> attMenu(a)));
        play.setOnClickListener(v -> togglePlay(a, bar, time, play));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user && player != null && playingId == a.id) player.seekTo(p);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        LinearLayout.LayoutParams lp = Ui.lp(Ui.MATCH, Ui.WRAP);
        lp.topMargin = ui.dp(8);
        row.setLayoutParams(lp);
        return row;
    }

    private void togglePlay(Store.Att a, SeekBar bar, TextView time, ImageView btn) {
        if (player != null && playingId == a.id) {
            if (player.isPlaying()) pausePlayer();
            else {
                player.start();
                btn.setImageDrawable(new Glyph("pause", Theme.BG));
                root.post(progressRun);
            }
            return;
        }
        stopPlayer();
        File f = Media.plain(this, a);
        if (f == null) {
            toast("Не удалось открыть запись");
            return;
        }
        try {
            player = new MediaPlayer();
            player.setDataSource(f.getPath());
            player.prepare();
            player.setOnCompletionListener(mp -> {
                btn.setImageDrawable(new Glyph("play", Theme.BG));
                bar.setProgress(0);
                time.setText(Fmt.duration(mp.getDuration()));
                stopPlayer();
            });
            player.start();
            playingId = a.id;
            playingBar = bar;
            playingTime = time;
            playingBtn = btn;
            btn.setImageDrawable(new Glyph("pause", Theme.BG));
            root.post(progressRun);
        } catch (Exception e) {
            stopPlayer();
            toast("Не удалось воспроизвести");
        }
    }

    private void pausePlayer() {
        if (player == null) return;
        try {
            if (player.isPlaying()) player.pause();
        } catch (IllegalStateException ignored) {
        }
        if (playingBtn != null) playingBtn.setImageDrawable(new Glyph("play", Theme.BG));
        root.removeCallbacks(progressRun);
    }

    private void stopPlayer() {
        root.removeCallbacks(progressRun);
        if (player != null) {
            try {
                player.release();
            } catch (Exception ignored) {
            }
        }
        if (playingBtn != null) playingBtn.setImageDrawable(new Glyph("play", Theme.BG));
        player = null;
        playingId = 0;
        playingBar = null;
        playingTime = null;
        playingBtn = null;
    }

    // ================================================================== картинки и рисунки

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
                .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(Intent.createChooser(i, "Выберите картинку"), REQ_IMAGE);
        } catch (Exception e) {
            toast("Нет приложения для выбора картинок");
        }
    }

    private void takePhoto() {
        File dir = Files.root(this, "cam");
        String name = "cam_" + System.currentTimeMillis() + ".jpg";
        new File(dir, name).delete();
        cameraUri = Files.uri("cam", name);
        Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).putExtra(android.provider.MediaStore.EXTRA_OUTPUT, cameraUri)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        i.setClipData(ClipData.newRawUri("", cameraUri));
        try {
            startActivityForResult(i, REQ_CAMERA);
        } catch (Exception e) {
            toast("Нет приложения камеры");
        }
    }

    private void addImages(List<Uri> uris) {
        long id = ensureSaved();
        byte[] key = note.locked ? Lock.key() : null;
        if (note.locked && key == null) return;
        toast(uris.size() > 1 ? "Добавляю " + uris.size() + " картинки…" : "Добавляю картинку…");
        Media.IO.execute(() -> {
            int ok = 0;
            for (Uri u : uris) {
                Store.Att a = Media.importImage(this, u, key);
                if (a == null) continue;
                a.note = id;
                store.addAttachment(a);
                ok++;
            }
            int n = ok;
            Media.MAIN.post(() -> {
                if (n == 0) toast("Не удалось открыть картинку");
                atts = store.attachments(id);
                renderAttachments();
                note.edited = System.currentTimeMillis();
                saveMeta();
            });
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (note == null) return;
        if (req == REQ_IMAGE && res == RESULT_OK && data != null) {
            ArrayList<Uri> uris = new ArrayList<>();
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) uris.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData() != null) uris.add(data.getData());
            if (!uris.isEmpty()) addImages(uris);
        } else if (req == REQ_CAMERA) {
            Uri u = cameraUri;
            cameraUri = null;
            if (res == RESULT_OK && u != null) {
                ArrayList<Uri> l = new ArrayList<>();
                l.add(u);
                addImages(l);
            }
        } else if ((req == REQ_SKETCH || req == REQ_SKETCH_EDIT) && res == RESULT_OK && data != null) {
            String path = data.getStringExtra("path");
            if (path != null) addDrawing(new File(path), req == REQ_SKETCH_EDIT ? editingDrawing : 0);
            editingDrawing = 0;
        } else if (req == REQ_EXPORT && res == RESULT_OK && data != null && data.getData() != null) {
            String t = title.getText().toString().trim();
            try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                out.write(((t.isEmpty() ? "" : "# " + t + "\n\n") + text()).getBytes(StandardCharsets.UTF_8));
                toast("Сохранено");
            } catch (Exception e) {
                toast("Не удалось сохранить файл");
            }
        }
    }

    private void addDrawing(File png, long replaceId) {
        long id = ensureSaved();
        byte[] key = note.locked ? Lock.key() : null;
        if (note.locked && key == null) return;
        Media.IO.execute(() -> {
            try {
                android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeFile(png.getPath(), o);
                String name;
                try (InputStream in = new FileInputStream(png)) {
                    name = Media.write(this, in, ".png", key);
                }
                png.delete();
                Store.Att old = replaceId > 0 ? store.attachment(replaceId) : null;
                if (old != null) {
                    Media.deleteFile(this, old);
                    old.file = name;
                    old.w = o.outWidth;
                    old.h = o.outHeight;
                    store.updateAttachment(old);
                } else {
                    Store.Att a = new Store.Att();
                    a.note = id;
                    a.kind = Store.DRAWING;
                    a.file = name;
                    a.w = o.outWidth;
                    a.h = o.outHeight;
                    store.addAttachment(a);
                }
            } catch (Exception e) {
                Media.MAIN.post(() -> toast("Не удалось сохранить рисунок"));
            }
            Media.MAIN.post(() -> {
                atts = store.attachments(id);
                renderAttachments();
                note.edited = System.currentTimeMillis();
                saveMeta();
            });
        });
    }

    // ================================================================== голос

    private void startRecording() {
        if (recorder != null) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingKind = "voice";
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        hideKeyboard();
        stopPlayer();
        try {
            recFile = new File(getCacheDir(), "rec_" + System.currentTimeMillis() + ".m4a");
            recorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(96_000);
            recorder.setAudioSamplingRate(44_100);
            recorder.setOutputFile(recFile.getPath());
            recorder.prepare();
            recorder.start();
            recStart = System.currentTimeMillis();
            recPausedTotal = 0;
            recPaused = false;
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            showRecPanel();
        } catch (Exception e) {
            if (recorder != null) recorder.release();
            recorder = null;
            toast("Микрофон недоступен");
        }
    }

    private long recElapsed() {
        long now = recPaused ? recPausedAt : System.currentTimeMillis();
        return now - recStart - recPausedTotal;
    }

    private void showRecPanel() {
        LinearLayout p = ui.col();
        p.setPadding(ui.dp(22), ui.dp(18), ui.dp(22), ui.dp(18));
        p.setBackground(Ui.stroke(0xF2181326, Theme.alpha(0xFFFF4F6A, 140), ui.dp(1), ui.dp(26)));
        p.setElevation(ui.dp(14));
        p.setClickable(true);
        LinearLayout top = ui.row();
        View dot = new View(this);
        dot.setBackground(Ui.oval(0xFFFF4F6A));
        top.addView(dot, Ui.lp(ui.dp(12), ui.dp(12)));
        dot.animate().alpha(0.2f).setDuration(600).withEndAction(new Runnable() {
            boolean on;

            @Override
            public void run() {
                if (recorder == null) return;
                on = !on;
                dot.animate().alpha(on ? 1f : 0.2f).setDuration(600).withEndAction(this).start();
            }
        }).start();
        TextView label = ui.text("Запись голоса", 15, Theme.TEXT, true);
        top.addView(label, Ui.margins(0, Ui.WRAP, ui.dp(12), 0, 0, 0));
        ((LinearLayout.LayoutParams) label.getLayoutParams()).weight = 1f;
        recTime = ui.text("0:00", 22, Theme.TEXT, true);
        recTime.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        top.addView(recTime);
        p.addView(top);
        recLevel = new LevelView(this);
        p.addView(recLevel, Ui.margins(Ui.MATCH, ui.dp(48), 0, ui.dp(14), 0, ui.dp(14)));
        LinearLayout buttons = ui.row();
        buttons.addView(ui.button("Отмена", false, v -> stopRecording(false)), Ui.lp(0, Ui.WRAP, 1f));
        TextView pause = ui.button("Пауза", false, null);
        pause.setOnClickListener(v -> {
            if (recorder == null || Build.VERSION.SDK_INT < 24) return;
            try {
                if (recPaused) {
                    recorder.resume();
                    recPausedTotal += System.currentTimeMillis() - recPausedAt;
                    recPaused = false;
                    pause.setText("Пауза");
                } else {
                    recorder.pause();
                    recPausedAt = System.currentTimeMillis();
                    recPaused = true;
                    pause.setText("Дальше");
                }
            } catch (Exception ignored) {
            }
        });
        buttons.addView(pause, Ui.margins(0, Ui.WRAP, ui.dp(10), 0, ui.dp(10), 0));
        ((LinearLayout.LayoutParams) pause.getLayoutParams()).weight = 1f;
        buttons.addView(ui.button("Готово", true, v -> stopRecording(true)), Ui.lp(0, Ui.WRAP, 1f));
        p.addView(buttons);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM);
        lp.setMargins(ui.dp(12), 0, ui.dp(12), ui.dp(16));
        recPanel = p;
        root.addView(p, lp);
        p.setTranslationY(ui.dp(200));
        p.animate().translationY(0).setDuration(220).start();
        root.post(new Runnable() {
            @Override
            public void run() {
                if (recorder == null) return;
                recTime.setText(Fmt.duration(recElapsed()));
                if (!recPaused) {
                    try {
                        recLevel.push(recorder.getMaxAmplitude() / 32767f);
                    } catch (Exception ignored) {
                    }
                }
                root.postDelayed(this, 80);
            }
        });
    }

    private void stopRecording(boolean keep) {
        if (recorder == null) return;
        long dur = recElapsed();
        boolean ok = true;
        try {
            recorder.stop();
        } catch (Exception e) {
            ok = false; // слишком короткая запись
        }
        recorder.release();
        recorder = null;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (recPanel != null) {
            View p = recPanel;
            p.animate().translationY(ui.dp(220)).setDuration(180).withEndAction(() -> root.removeView(p)).start();
            recPanel = null;
        }
        File f = recFile;
        recFile = null;
        if (!keep || !ok || dur < 600) {
            if (f != null) f.delete();
            if (keep && (!ok || dur < 600)) toast("Слишком короткая запись");
            return;
        }
        long id = ensureSaved();
        byte[] key = note.locked ? Lock.key() : null;
        Media.IO.execute(() -> {
            try (InputStream in = new FileInputStream(f)) {
                Store.Att a = new Store.Att();
                a.note = id;
                a.kind = Store.AUDIO;
                a.duration = dur;
                a.file = Media.write(this, in, ".m4a", key);
                store.addAttachment(a);
            } catch (Exception e) {
                Media.MAIN.post(() -> toast("Не удалось сохранить запись"));
            }
            f.delete();
            Media.MAIN.post(() -> {
                atts = store.attachments(id);
                renderAttachments();
                note.edited = System.currentTimeMillis();
                saveMeta();
            });
        });
    }

    private void cancelRecording() {
        stopRecording(false);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
        if (req == REQ_MIC) {
            if (ok && "voice".equals(pendingKind)) startRecording();
            else if (!ok) toast("Без доступа к микрофону записать голос нельзя");
            pendingKind = null;
        } else if (req == REQ_NOTIF && !ok) {
            toast("Уведомления выключены — напоминание не появится в шторке");
        }
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent e) {
        if (e.isCtrlPressed()) {
            switch (code) {
                case KeyEvent.KEYCODE_Z: if (e.isShiftPressed()) redo(); else undo(); return true;
                case KeyEvent.KEYCODE_Y: redo(); return true;
                case KeyEvent.KEYCODE_B: wrap("**"); return true;
                case KeyEvent.KEYCODE_I: wrap("_"); return true;
                case KeyEvent.KEYCODE_L: linePrefix(EditOps.P_CHECK); return true;
                case KeyEvent.KEYCODE_S: save(false); toast("Сохранено"); return true;
                default: break;
            }
        }
        return super.onKeyDown(code, e);
    }

    /** Полоски уровня громкости во время записи. */
    static final class LevelView extends View {
        private final float[] levels = new float[48];
        private int head;
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        LevelView(android.content.Context c) {
            super(c);
            p.setColor(0xFFFF4F6A);
            p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
        }

        void push(float v) {
            levels[head] = Math.max(0.04f, Math.min(1f, (float) Math.sqrt(v)));
            head = (head + 1) % levels.length;
            invalidate();
        }

        @Override
        protected void onDraw(android.graphics.Canvas c) {
            int n = levels.length;
            float step = getWidth() / (float) n, cy = getHeight() / 2f;
            p.setStrokeWidth(step * 0.55f);
            for (int i = 0; i < n; i++) {
                float v = levels[(head + i) % n];
                float h = Math.max(step * 0.3f, v * getHeight() * 0.9f) / 2f;
                p.setAlpha(90 + Math.round(165 * (i / (float) n)));
                float x = step * i + step / 2;
                c.drawLine(x, cy - h, x, cy + h, p);
            }
        }
    }
}
