package com.neondrift.notes;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.ReplacementSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/** Превращает разметку Md в стили Android: в редакторе (маркеры видны) и в режиме чтения. */
final class Styler {
    private Styler() {}

    static final int HIGHLIGHT_BG = 0x66FFD447;
    static final int CODE_BG = 0x26FFFFFF;
    static final int CODE_FG = 0xFFFFC2E2;

    /** Наложенный стиль: тип разметки и созданные для него объекты Android. */
    static final class Applied {
        final int key;
        final Object[] objects;

        Applied(int key, Object[] objects) {
            this.key = key;
            this.objects = objects;
        }
    }

    /**
     * Наложить стили на редактируемый текст. Меняются только стили, которые действительно изменились:
     * при наборе внутри слова не трогаются сотни остальных — длинные заметки не тормозят.
     */
    static void editor(Editable e, List<Applied> applied, int textColor) {
        String text = e.toString();
        if (text.length() > 200_000) { // огромные тексты не раскрашиваем
            for (Applied a : applied) for (Object o : a.objects) e.removeSpan(o);
            applied.clear();
            return;
        }
        java.util.HashMap<Long, Md.Span> want = new java.util.HashMap<>();
        for (Md.Span s : Md.highlight(text)) {
            if (s.end <= s.start || s.end > e.length()) continue;
            want.put(id(keyOf(s, text), s.start, s.end), s);
        }
        ArrayList<Applied> kept = new ArrayList<>();
        for (Applied a : applied) {
            int st = e.getSpanStart(a.objects[0]), en = e.getSpanEnd(a.objects[0]);
            if (st >= 0 && want.remove(id(a.key, st, en)) != null) kept.add(a);
            else for (Object o : a.objects) e.removeSpan(o);
        }
        applied.clear();
        applied.addAll(kept);
        for (Md.Span s : want.values()) {
            List<Object> os = spansFor(s.type, false, textColor, e, s);
            if (os.isEmpty()) continue;
            for (Object o : os) e.setSpan(o, s.start, s.end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            applied.add(new Applied(keyOf(s, text), os.toArray()));
        }
    }

    /** Галочка: отмеченная и пустая — разные стили. */
    private static int keyOf(Md.Span s, String text) {
        return s.type == Md.BOX && isChecked(text, s) ? 100 + s.type : s.type;
    }

    private static long id(int key, int start, int end) {
        return ((long) key << 50) ^ ((long) start << 25) ^ end;
    }

    private static List<Object> spansFor(int type, boolean read, int textColor, CharSequence text, Md.Span s) {
        ArrayList<Object> out = new ArrayList<>(2);
        switch (type) {
            case Md.H1: out.add(new RelativeSizeSpan(1.45f)); out.add(new StyleSpan(Typeface.BOLD)); break;
            case Md.H2: out.add(new RelativeSizeSpan(1.25f)); out.add(new StyleSpan(Typeface.BOLD)); break;
            case Md.H3: out.add(new RelativeSizeSpan(1.1f)); out.add(new StyleSpan(Typeface.BOLD)); out.add(new ForegroundColorSpan(Theme.ACCENT)); break;
            case Md.BOLD: out.add(new StyleSpan(Typeface.BOLD)); break;
            case Md.ITALIC: out.add(new StyleSpan(Typeface.ITALIC)); break;
            case Md.STRIKE: out.add(new StrikethroughSpan()); out.add(new ForegroundColorSpan(Theme.MUTED)); break;
            case Md.CODE:
            case Md.CODEBLOCK:
                out.add(new TypefaceSpan("monospace"));
                out.add(new BackgroundColorSpan(CODE_BG));
                out.add(new ForegroundColorSpan(CODE_FG));
                break;
            case Md.HIGHLIGHT: out.add(new BackgroundColorSpan(HIGHLIGHT_BG)); break;
            case Md.MARK: out.add(new ForegroundColorSpan(Theme.alpha(textColor, 90))); break;
            case Md.QUOTE: out.add(new ForegroundColorSpan(Theme.mix(textColor, Theme.MUTED, 0.5f))); out.add(new StyleSpan(Typeface.ITALIC)); break;
            case Md.BULLET:
                if (read) out.add(new ForegroundColorSpan(Theme.ACCENT));
                else out.add(new DotSpan(Theme.ACCENT));
                break;
            case Md.NUMBER: out.add(new ForegroundColorSpan(Theme.ACCENT)); out.add(new StyleSpan(Typeface.BOLD)); break;
            case Md.BOX: {
                boolean checked = isChecked(text, s);
                out.add(new BoxSpan(checked, Theme.ACCENT));
                break;
            }
            case Md.CHECKED: out.add(new StrikethroughSpan()); out.add(new ForegroundColorSpan(Theme.MUTED)); break;
            case Md.TAG: out.add(new ForegroundColorSpan(Theme.ACCENT2)); break;
            case Md.RULE: out.add(new ForegroundColorSpan(Theme.LINE)); break;
            default: break;
        }
        return out;
    }

    private static boolean isChecked(CharSequence text, Md.Span s) {
        for (int i = s.start; i < s.end && i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == 'x' || c == 'X' || c == '☑') return true;
        }
        return false;
    }

    /**
     * Текст для режима чтения и карточек. onCheck — нажатие на галочку (номер строки исходника),
     * onTag — нажатие на тег. null — без нажатий (карточки, виджет).
     */
    static SpannableStringBuilder rendered(Md.Rendered r, int textColor, IntConsumer onCheck, Consumer<String> onTag) {
        SpannableStringBuilder sb = new SpannableStringBuilder(r.text);
        for (Md.Span s : r.spans) {
            if (s.end <= s.start || s.end > sb.length()) continue;
            for (Object o : spansFor(s.type, true, textColor, sb, s)) sb.setSpan(o, s.start, s.end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (s.type == Md.TAG && onTag != null) {
                String tag = r.text.substring(s.start + 1, s.end).toLowerCase(java.util.Locale.ROOT);
                sb.setSpan(new Tap(() -> onTag.accept(tag)), s.start, s.end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            if (s.type == Md.QUOTE && r.text.charAt(s.start) == '▎') {
                sb.setSpan(new ForegroundColorSpan(Theme.ACCENT), s.start, s.start + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
        if (onCheck != null) {
            for (Md.Check c : r.checks) {
                int line = c.line;
                int end = Math.min(sb.length(), c.pos + 2);
                sb.setSpan(new Tap(() -> onCheck.accept(line)), c.pos, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
        return sb;
    }

    /** Нажимаемый фрагмент без подчёркивания. */
    static final class Tap extends ClickableSpan {
        final Runnable r;

        Tap(Runnable r) {
            this.r = r;
        }

        @Override
        public void onClick(View widget) {
            r.run();
        }

        @Override
        public void updateDrawState(TextPaint ds) {
        }
    }

    /** Галочка вместо «- [ ]» в редакторе и вместо «☐» в чтении. */
    static final class BoxSpan extends ReplacementSpan {
        final boolean checked;
        final int color;
        private final RectF r = new RectF();
        private final Path p = new Path();

        BoxSpan(boolean checked, int color) {
            this.checked = checked;
            this.color = color;
        }

        @Override
        public int getSize(Paint paint, CharSequence text, int start, int end, Paint.FontMetricsInt fm) {
            if (fm != null) paint.getFontMetricsInt(fm);
            return Math.round(paint.getTextSize() * 1.3f);
        }

        @Override
        public void draw(Canvas c, CharSequence text, int start, int end, float x, int top, int y, int bottom, Paint paint) {
            float ts = paint.getTextSize(), side = ts * 0.92f;
            float cy = y - ts * 0.34f, left = x + ts * 0.1f;
            r.set(left, cy - side / 2, left + side, cy + side / 2);
            int oldColor = paint.getColor();
            Paint.Style oldStyle = paint.getStyle();
            float oldWidth = paint.getStrokeWidth();
            paint.setAntiAlias(true);
            if (checked) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(color);
                c.drawRoundRect(r, side * 0.28f, side * 0.28f, paint);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(side * 0.13f);
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setStrokeJoin(Paint.Join.ROUND);
                paint.setColor(Theme.BG);
                p.reset();
                p.moveTo(r.left + side * 0.24f, r.top + side * 0.52f);
                p.lineTo(r.left + side * 0.43f, r.top + side * 0.70f);
                p.lineTo(r.left + side * 0.77f, r.top + side * 0.32f);
                c.drawPath(p, paint);
            } else {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(side * 0.1f);
                paint.setColor(Theme.alpha(color, 220));
                float in = side * 0.05f;
                r.inset(in, in);
                c.drawRoundRect(r, side * 0.26f, side * 0.26f, paint);
            }
            paint.setColor(oldColor);
            paint.setStyle(oldStyle);
            paint.setStrokeWidth(oldWidth);
        }
    }

    /** Точка вместо «-» у маркированного списка в редакторе. */
    static final class DotSpan extends ReplacementSpan {
        final int color;

        DotSpan(int color) {
            this.color = color;
        }

        @Override
        public int getSize(Paint paint, CharSequence text, int start, int end, Paint.FontMetricsInt fm) {
            if (fm != null) paint.getFontMetricsInt(fm);
            return Math.round(paint.getTextSize() * 0.75f);
        }

        @Override
        public void draw(Canvas c, CharSequence text, int start, int end, float x, int top, int y, int bottom, Paint paint) {
            int old = paint.getColor();
            Paint.Style os = paint.getStyle();
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            float ts = paint.getTextSize();
            c.drawCircle(x + ts * 0.32f, y - ts * 0.33f, ts * 0.14f, paint);
            paint.setColor(old);
            paint.setStyle(os);
        }
    }
}
