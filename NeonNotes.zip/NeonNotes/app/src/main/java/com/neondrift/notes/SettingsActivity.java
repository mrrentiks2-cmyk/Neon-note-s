package com.neondrift.notes;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.function.Consumer;

/** Настройки: оформление, заметки, сейф, резервные копии. */
public class SettingsActivity extends Base {
    private static final int REQ_EXPORT = 1, REQ_IMPORT = 2;

    private LinearLayout box;
    private ScrollView scroll;
    private PinPad pin;
    private Backup.Plan pendingPlan;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        FrameLayout root = new FrameLayout(this);
        LinearLayout page = ui.col();
        page.setBackgroundColor(Theme.BG);
        LinearLayout top = ui.row();
        top.setPadding(ui.dp(6), ui.dp(10), ui.dp(16), ui.dp(6));
        top.addView(ui.iconButton("back", Theme.TEXT, 44, 11, v -> finish()));
        top.addView(ui.text("Настройки", 20, Theme.TEXT, true), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(8), 0, 0, 0));
        page.addView(top);
        scroll = new ScrollView(this);
        box = ui.col();
        box.setPadding(ui.dp(20), 0, ui.dp(20), ui.dp(40));
        scroll.addView(box, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        page.addView(scroll, Ui.lp(Ui.MATCH, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        pin = new PinPad(this, ui);
        root.addView(pin, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        setContentView(root);
        build();
    }

    private void rebuild() {
        int y = scroll.getScrollY();
        build();
        scroll.post(() -> scroll.scrollTo(0, y));
    }

    private void build() {
        box.removeAllViews();

        section("ОФОРМЛЕНИЕ");
        LinearLayout acc = chipRow();
        for (int i = 0; i < Theme.ACCENT_NAMES.length; i++) {
            int k = i;
            TextView c = ui.chip(Theme.ACCENT_NAMES[i], prefs.accent() == i, v -> {
                prefs.put("accent", k);
                Theme.load(this);
                recreate();
                NoteWidget.refreshAll(this);
            });
            android.graphics.drawable.GradientDrawable d = Ui.oval(Theme.ACCENTS[i]);
            d.setSize(ui.dp(10), ui.dp(10));
            c.setCompoundDrawablesRelativeWithIntrinsicBounds(d, null, null, null);
            c.setCompoundDrawablePadding(ui.dp(8));
            add(acc, c);
        }
        label("Вид списка");
        LinearLayout view = chipRow();
        add(view, ui.chip("Сетка", prefs.view() == 0, v -> { prefs.put("view", 0); rebuild(); }));
        add(view, ui.chip("Список", prefs.view() == 1, v -> { prefs.put("view", 1); rebuild(); }));
        label("Строк текста в карточке");
        LinearLayout lines = chipRow();
        for (int n : new int[]{4, 8, 12, 20}) add(lines, ui.chip(String.valueOf(n), prefs.previewLines() == n, v -> { prefs.put("previewLines", n); rebuild(); }));
        stepper("Размер текста в редакторе", prefs.textSize() + " sp",
                () -> { prefs.put("textSize", Math.max(13, prefs.textSize() - 1)); rebuild(); },
                () -> { prefs.put("textSize", Math.min(28, prefs.textSize() + 1)); rebuild(); });
        toggle("Показывать теги на карточках", null, prefs.showTags(), on -> prefs.put("showTags", on));

        section("ЗАМЕТКИ");
        toggle("Выполненные пункты — вниз", "Отмеченный пункт чек-листа уезжает в конец списка", prefs.checkedToBottom(), on -> prefs.put("checkedToBottom", on));
        toggle("Открывать в режиме чтения", "Ссылки и галочки нажимаются, текст не меняется случайно. Двойное нажатие — редактирование", prefs.openPreview(), on -> prefs.put("openPreview", on));
        toggle("Очищать корзину через 30 дней", null, prefs.autoPurge(), on -> prefs.put("autoPurge", on));
        stepper("«Утром» для напоминаний", prefs.morningHour() + ":00",
                () -> { prefs.put("morningHour", Math.max(5, prefs.morningHour() - 1)); rebuild(); },
                () -> { prefs.put("morningHour", Math.min(12, prefs.morningHour() + 1)); rebuild(); });

        section("СЕЙФ");
        if (!Lock.isSet(this)) {
            note("Сейф шифрует заметки и их вложения ключом от вашего PIN-кода (AES-256). Без PIN прочитать их нельзя — даже нам.");
            button("Создать сейф", () -> pin.create("Новый сейф", p -> Lock.setup(this, p), () -> {
                toast("Сейф создан");
                rebuild();
            }, null));
        } else {
            label("Закрывать сейф, когда приложение свёрнуто");
            LinearLayout to = chipRow();
            int[] secs = {0, 60, 300, 1800};
            String[] names = {"Сразу", "Через минуту", "Через 5 минут", "Через 30 минут"};
            for (int i = 0; i < secs.length; i++) {
                int s = secs[i];
                add(to, ui.chip(names[i], prefs.lockTimeout() == s, v -> { prefs.put("lockTimeout", s); rebuild(); }));
            }
            if (Bio.supported(this)) {
                toggle("Открывать отпечатком пальца", "PIN всё равно понадобится после добавления нового отпечатка в систему",
                        Bio.enabled(this), on -> {
                            if (!on) {
                                Bio.disable(this);
                                return;
                            }
                            withVault(() -> Bio.enable(this, Lock.key(), () -> {
                                toast("Готово: сейф открывается отпечатком");
                                rebuild();
                            }, msg -> {
                                if (!msg.isEmpty()) toast(msg);
                                rebuild();
                            }));
                        });
            }
            button("Сменить PIN", () -> withVault(() -> pin.create("Новый PIN", p -> Lock.changePin(this, p), () -> {
                toast("PIN изменён");
                rebuild();
            }, null)));
            if (Lock.isOpen()) button("Закрыть сейф сейчас", () -> {
                Lock.lock(this);
                toast("Сейф закрыт");
                rebuild();
            });
            button("Забыли PIN? Сбросить сейф", () -> confirm("Сбросить сейф?",
                    "Все заметки из сейфа будут удалены без возможности восстановления. Остальные заметки не пострадают.", "Удалить сейф", () -> {
                        int n = Lock.reset(this);
                        toast("Сейф удалён: " + Fmt.count(n, "заметка", "заметки", "заметок"));
                        rebuild();
                    }));
        }

        section("РЕЗЕРВНАЯ КОПИЯ");
        note("Один ZIP-файл: все заметки, папки, картинки, рисунки и голос. Заметки сейфа остаются зашифрованными. "
                + "Внутри есть и папка markdown — заметки обычными файлами, их откроет любой редактор.");
        button("Сохранить копию…", () -> {
            String name = "neon-notes-" + new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(new Date()) + ".zip";
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/zip")
                    .putExtra(Intent.EXTRA_TITLE, name);
            try {
                startActivityForResult(i, REQ_EXPORT);
            } catch (Exception e) {
                toast("Нет приложения для выбора папки");
            }
        });
        button("Восстановить из копии…", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                    .putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream"});
            try {
                startActivityForResult(i, REQ_IMPORT);
            } catch (Exception e) {
                toast("Нет приложения для выбора файла");
            }
        });
        note("Восстановление добавляет заметки к текущим и пропускает те, что уже есть.");

        section("О ПРИЛОЖЕНИИ");
        Store.Counts k = Store.get(this).counts();
        String ver = "";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        note("Neon Notes " + ver + "\n" + Fmt.count(k.notes, "заметка", "заметки", "заметок") + ", в архиве " + k.archive
                + ", в сейфе " + k.vault + ", в корзине " + k.trash + ".\nВсё хранится только на этом устройстве, приложению не нужен интернет.");
    }

    private void withVault(Runnable r) {
        if (Lock.isOpen()) {
            r.run();
            return;
        }
        pin.ask("Сейф", "Введите текущий PIN-код", p -> Lock.unlock(this, p), r, this::rebuild);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (req == REQ_EXPORT) {
            toast("Сохраняю копию…");
            Media.IO.execute(() -> {
                String msg;
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    Backup.Stats s = Backup.export(this, out);
                    msg = "Копия сохранена: " + Fmt.count(s.notes, "заметка", "заметки", "заметок")
                            + (s.files > 0 ? ", " + Fmt.count(s.files, "файл", "файла", "файлов") : "");
                } catch (Exception e) {
                    msg = "Не удалось сохранить копию";
                }
                String m = msg;
                Media.MAIN.post(() -> dialog().setTitle("Резервная копия").setMessage(m).setPositiveButton("OK", null).show());
            });
        } else if (req == REQ_IMPORT) {
            toast("Читаю копию…");
            Media.IO.execute(() -> {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    Backup.Plan plan = Backup.read(this, in);
                    Media.MAIN.post(() -> confirmImport(plan));
                } catch (Exception e) {
                    String m = e.getMessage() != null ? e.getMessage() : "Не удалось прочитать копию";
                    Media.MAIN.post(() -> dialog().setTitle("Восстановление").setMessage(m).setPositiveButton("OK", null).show());
                }
            });
        }
    }

    private void confirmImport(Backup.Plan plan) {
        pendingPlan = plan;
        String msg = "В копии " + Fmt.count(plan.notes, "заметка", "заметки", "заметок")
                + (plan.locked > 0 ? ", из них в сейфе — " + plan.locked : "") + ". Добавить их к текущим?";
        dialog().setTitle("Восстановление").setMessage(msg)
                .setPositiveButton("Добавить", (d, w) -> {
                    if (plan.needsBackupPin(this)) askKeys(plan);
                    else runImport(plan, null, null);
                })
                .setNegativeButton("Отмена", (d, w) -> plan.cleanup())
                .setOnCancelListener(d -> plan.cleanup())
                .show();
    }

    /** Копия зашифрована другим PIN: нужен открытый текущий сейф и PIN от копии. */
    private void askKeys(Backup.Plan plan) {
        Runnable askBackup = () -> {
            final byte[][] holder = new byte[1][];
            pin.ask("PIN от копии", "Заметки сейфа в копии зашифрованы другим PIN-кодом. Введите его, чтобы перенести их в ваш сейф.",
                    p -> (holder[0] = plan.checkPin(p)) != null,
                    () -> runImport(plan, holder[0], Lock.key()),
                    () -> runImport(plan, null, null));
        };
        if (Lock.isOpen()) askBackup.run();
        else pin.ask("Сейф", "Сначала откройте свой сейф", p -> Lock.unlock(this, p), askBackup, () -> runImport(plan, null, null));
    }

    private void runImport(Backup.Plan plan, byte[] backupKey, byte[] currentKey) {
        toast("Восстанавливаю…");
        Media.IO.execute(() -> {
            Backup.Stats s = Backup.apply(this, plan, backupKey, currentKey);
            StringBuilder m = new StringBuilder("Добавлено: " + Fmt.count(s.added, "заметка", "заметки", "заметок"));
            if (s.files > 0) m.append(", ").append(Fmt.count(s.files, "файл", "файла", "файлов"));
            if (s.skipped > 0) m.append("\nУже были: ").append(s.skipped);
            if (s.lockedSkipped > 0) m.append("\nНе перенесено из сейфа: ").append(s.lockedSkipped).append(" (нужен PIN от копии)");
            Media.MAIN.post(() -> {
                pendingPlan = null;
                NoteWidget.refreshAll(this);
                dialog().setTitle("Восстановление").setMessage(m.toString()).setPositiveButton("OK", null).show();
                rebuild();
            });
        });
    }

    @Override
    public void onBackPressed() {
        if (pin.isShowing()) pin.cancel();
        else super.onBackPressed();
    }

    // ================================================================== блоки

    private void section(String s) {
        box.addView(ui.label(s), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(4), ui.dp(26), 0, ui.dp(8)));
    }

    private void label(String s) {
        box.addView(ui.text(s, 14, Theme.TEXT, false), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(4), ui.dp(14), 0, ui.dp(8)));
    }

    private void note(String s) {
        TextView t = ui.text(s, 12.5f, Theme.MUTED, false);
        t.setLineSpacing(0, 1.3f);
        box.addView(t, Ui.margins(Ui.MATCH, Ui.WRAP, ui.dp(4), ui.dp(6), 0, 0));
    }

    private void button(String s, Runnable r) {
        box.addView(ui.button(s, false, v -> r.run()), Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(8), 0, 0));
    }

    private LinearLayout chipRow() {
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = ui.row();
        hs.addView(row);
        box.addView(hs, Ui.lp(Ui.MATCH, Ui.WRAP));
        return row;
    }

    private void add(LinearLayout row, TextView chip) {
        LinearLayout.LayoutParams lp = Ui.lp(Ui.WRAP, Ui.WRAP);
        lp.rightMargin = ui.dp(8);
        row.addView(chip, lp);
    }

    private void stepper(String title, String value, Runnable minus, Runnable plus) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(4), ui.dp(10), 0, ui.dp(6));
        row.addView(ui.text(title, 15, Theme.TEXT, false), Ui.lp(0, Ui.WRAP, 1f));
        ImageView m = ui.iconButton("minus", Theme.TEXT, 40, 11, v -> minus.run());
        m.setBackground(Ui.ripple(Ui.oval(Theme.SURFACE2), Ui.oval(0xFFFFFFFF)));
        row.addView(m);
        TextView v = ui.text(value, 15, Theme.ACCENT, true);
        v.setGravity(Gravity.CENTER);
        row.addView(v, Ui.lp(ui.dp(64), Ui.WRAP));
        ImageView p = ui.iconButton("plus", Theme.TEXT, 40, 11, x -> plus.run());
        p.setBackground(Ui.ripple(Ui.oval(Theme.SURFACE2), Ui.oval(0xFFFFFFFF)));
        row.addView(p);
        box.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP));
    }

    private void toggle(String title, String sub, boolean checked, Consumer<Boolean> changed) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(4), ui.dp(10), 0, ui.dp(10));
        LinearLayout tx = ui.col();
        tx.addView(ui.text(title, 15, Theme.TEXT, false));
        if (sub != null) {
            TextView s = ui.text(sub, 12, Theme.MUTED, false);
            s.setLineSpacing(0, 1.2f);
            tx.addView(s, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(3), 0, 0));
        }
        row.addView(tx, Ui.lp(0, Ui.WRAP, 1f));
        Switch s = new Switch(this);
        s.setChecked(checked);
        int[][] states = {{android.R.attr.state_checked}, {}};
        s.setThumbTintList(new ColorStateList(states, new int[]{Theme.ACCENT, 0xFFB8B0D0}));
        s.setTrackTintList(new ColorStateList(states, new int[]{Theme.alpha(Theme.ACCENT, 120), 0xFF3A3352}));
        s.setOnCheckedChangeListener((b, on) -> changed.accept(on));
        row.addView(s);
        row.setOnClickListener(v -> s.toggle());
        box.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP));
    }
}
