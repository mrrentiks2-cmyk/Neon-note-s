package com.neondrift.notes;

import android.content.Context;

import java.io.File;
import java.util.Base64;
import java.util.List;

/**
 * Сессия сейфа. Ключ живёт только в памяти: после ухода приложения в фон (и заданной паузы)
 * он стирается, а расшифрованные копии вложений удаляются.
 */
final class Lock {
    private Lock() {}

    private static byte[] key;
    private static long expires;

    static boolean isSet(Context c) {
        return new Prefs(c).vaultCheck() != null;
    }

    static synchronized boolean isOpen() {
        if (key != null && expires > 0 && System.currentTimeMillis() > expires) wipe();
        return key != null;
    }

    static synchronized byte[] key() {
        return isOpen() ? key : null;
    }

    /** Долгая операция (PBKDF2): вызывать не из главного потока. */
    static boolean setup(Context c, String pin) {
        byte[] salt = Vault.salt();
        byte[] k = Vault.derive(pin, salt);
        new Prefs(c).setVault(Base64.getEncoder().encodeToString(salt), Vault.seal(k, Vault.CHECK));
        synchronized (Lock.class) {
            key = k;
            expires = 0;
        }
        return true;
    }

    /** Проверить PIN без открытия сейфа: вернуть ключ или null. */
    static byte[] check(Context c, String pin) {
        Prefs p = new Prefs(c);
        if (p.vaultSalt() == null) return null;
        byte[] k = Vault.derive(pin, Base64.getDecoder().decode(p.vaultSalt()));
        return Vault.CHECK.equals(Vault.open(k, p.vaultCheck())) ? k : null;
    }

    static boolean unlock(Context c, String pin) {
        byte[] k = check(c, pin);
        if (k == null) return false;
        synchronized (Lock.class) {
            key = k;
            expires = 0;
        }
        return true;
    }

    /** Ключ, полученный по отпечатку: проверяем, что он подходит к сейфу. */
    static boolean setKey(Context c, byte[] k) {
        if (!Vault.CHECK.equals(Vault.open(k, new Prefs(c).vaultCheck()))) return false;
        synchronized (Lock.class) {
            key = k;
            expires = 0;
        }
        return true;
    }

    static synchronized void lock(Context c) {
        wipe();
        clearOpened(c);
    }

    private static void wipe() {
        if (key != null) java.util.Arrays.fill(key, (byte) 0);
        key = null;
        expires = 0;
    }

    /** Приложение ушло в фон. */
    static synchronized void onBackground(Context c) {
        if (key == null) return;
        int t = new Prefs(c).lockTimeout();
        if (t <= 0) lock(c);
        else expires = System.currentTimeMillis() + t * 1000L;
    }

    static synchronized void onForeground(Context c) {
        if (key != null && expires > 0 && System.currentTimeMillis() > expires) lock(c);
        expires = 0;
    }

    static void clearOpened(Context c) {
        File d = new File(c.getCacheDir(), "open");
        File[] fs = d.listFiles();
        if (fs != null) for (File f : fs) f.delete();
    }

    /**
     * Сменить PIN: все заметки и файлы сейфа перешифровываются новым ключом.
     * Сейф должен быть открыт. Долгая операция.
     */
    static boolean changePin(Context c, String pin) {
        byte[] old = key();
        if (old == null) return false;
        byte[] salt = Vault.salt();
        byte[] nk = Vault.derive(pin, salt);
        Store st = Store.get(c);
        List<Note> all = st.all();
        for (Note n : all) {
            if (!n.locked) continue;
            String plain = Vault.open(old, n.body);
            if (plain == null) continue;
            n.body = Vault.seal(nk, plain);
            st.update(n);
            for (Store.Att a : st.attachments(n.id)) Media.reseal(c, a, old, nk);
        }
        new Prefs(c).setVault(Base64.getEncoder().encodeToString(salt), Vault.seal(nk, Vault.CHECK));
        Bio.disable(c); // отпечаток хранил старый ключ — включается заново в настройках
        synchronized (Lock.class) {
            key = nk;
        }
        return true;
    }

    /** Забыли PIN: стереть сейф вместе со всеми заметками в нём. */
    static int reset(Context c) {
        Store st = Store.get(c);
        long[] ids = st.ids("locked=1");
        st.deleteForever(ids);
        Prefs p = new Prefs(c);
        p.remove("vaultSalt");
        p.remove("vaultCheck");
        Bio.disable(c);
        lock(c);
        return ids.length;
    }

    // ================================================================== заметки

    /** Расшифровать заметку для показа (в памяти). false — сейф закрыт или данные повреждены. */
    static boolean open(Note n) {
        if (!n.locked) return true;
        byte[] k = key();
        if (k == null) return false;
        if (n.body.isEmpty()) { // новая заметка в сейфе — ещё ничего не зашифровано
            n.openTitle = "";
            n.openBody = "";
            return true;
        }
        String s = Vault.open(k, n.body);
        if (s == null) return false;
        String[] tb = Vault.unpack(s);
        n.openTitle = tb[0];
        n.openBody = tb[1];
        return true;
    }

    /** Зашифровать открытый текст обратно в body. */
    static void seal(Note n, String title, String body) {
        byte[] k = key();
        if (k == null) throw new IllegalStateException("сейф закрыт");
        n.body = Vault.seal(k, Vault.pack(title, body));
        n.title = "";
        n.openTitle = title;
        n.openBody = body;
    }
}
