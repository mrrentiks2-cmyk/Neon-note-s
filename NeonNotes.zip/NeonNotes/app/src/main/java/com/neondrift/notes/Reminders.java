package com.neondrift.notes;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

/** Будильники напоминаний и уведомления о них. */
final class Reminders {
    private Reminders() {}

    static final String CHANNEL = "reminders";
    static final String ACTION_FIRE = "com.neondrift.notes.REMIND";
    static final String ACTION_SNOOZE = "com.neondrift.notes.SNOOZE";
    static final String ACTION_DONE = "com.neondrift.notes.DONE";
    static final String ACTION_LATE = "com.neondrift.notes.LATE";

    static PendingIntent alarm(Context c, long id, String action) {
        Intent i = new Intent(c, ReminderReceiver.class).setAction(action).setData(Uri.parse("note://" + id)).putExtra("id", id);
        return PendingIntent.getBroadcast(c, (int) id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Можно ли ставить точные будильники (на Android 12 пользователь может это запретить). */
    static boolean exact(Context c) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = c.getSystemService(AlarmManager.class);
        return am != null && am.canScheduleExactAlarms();
    }

    static void schedule(Context c, Note n) {
        if (n == null) return;
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am == null) return;
        PendingIntent pi = alarm(c, n.id, ACTION_FIRE);
        if (n.reminder <= 0 || n.fired || n.trashed > 0) {
            am.cancel(pi);
            return;
        }
        long when = Math.max(n.reminder, System.currentTimeMillis() + 1000);
        try {
            if (exact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    /** Отложить повторяющееся напоминание: разовый звонок, расписание не меняется. */
    static void later(Context c, long id, long when) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am == null) return;
        Intent i = new Intent(c, ReminderReceiver.class).setAction(ACTION_LATE).setData(Uri.parse("note://" + id + "/late")).putExtra("id", id);
        PendingIntent pi = PendingIntent.getBroadcast(c, (int) id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (exact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    static void cancel(Context c, long id) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am != null) am.cancel(alarm(c, id, ACTION_FIRE));
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel((int) id);
    }

    /** После перезагрузки, обновления приложения или смены времени: перевзвести всё, пропущенное — показать. */
    static void syncAll(Context c) {
        Store st = Store.get(c);
        long now = System.currentTimeMillis();
        for (Note n : st.withReminders()) {
            if (n.fired) continue;
            if (n.reminder <= now) fire(c, n);
            else schedule(c, n);
        }
    }

    /** Сработало напоминание: показать уведомление, у повторяющихся — назначить следующее. */
    static void fire(Context c, Note n) {
        Store st = Store.get(c);
        long now = System.currentTimeMillis();
        notify(c, n);
        if (n.repeat != Repeat.NONE) {
            n.reminder = Repeat.next(n.reminder, n.repeat, now);
            n.fired = false;
        } else {
            n.fired = true;
        }
        st.set(new long[]{n.id}, "reminder", n.reminder);
        st.set(new long[]{n.id}, "fired", n.fired ? 1 : 0);
        schedule(c, n);
    }

    static void channel(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null || nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Напоминания", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Напоминания из заметок");
        ch.enableVibration(true);
        ch.enableLights(true);
        ch.setLightColor(Theme.ACCENT);
        nm.createNotificationChannel(ch);
    }

    static void notify(Context c, Note n) {
        channel(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        String title, text;
        if (n.locked) {
            title = "Напоминание";
            text = "Заметка в сейфе";
        } else {
            String plain = Md.plain(n.body).trim();
            title = !n.title.trim().isEmpty() ? n.title.trim() : firstLine(plain, "Напоминание");
            text = !n.title.trim().isEmpty() ? plain : rest(plain);
            if (text.length() > 600) text = text.substring(0, 600) + "…";
        }
        Intent open = new Intent(c, NoteActivity.class).putExtra("id", n.id).setData(Uri.parse("note://" + n.id))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(c, (int) n.id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_note)
                .setContentTitle(title)
                .setContentText(text.isEmpty() ? Fmt.reminder(n.reminder, System.currentTimeMillis()) : text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setColor(Theme.ACCENT)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setContentIntent(content)
                .setAutoCancel(true)
                .setShowWhen(true)
                .setWhen(n.reminder)
                .setVisibility(n.locked ? Notification.VISIBILITY_PRIVATE : Notification.VISIBILITY_PUBLIC)
                .addAction(new Notification.Action.Builder(null, "Через 10 мин", alarm(c, n.id, ACTION_SNOOZE)).build())
                .addAction(new Notification.Action.Builder(null, "Через час", alarmHour(c, n.id)).build())
                .addAction(new Notification.Action.Builder(null, "Готово", alarm(c, n.id, ACTION_DONE)).build());
        try {
            nm.notify((int) n.id, b.build());
        } catch (SecurityException ignored) {
            // нет разрешения на уведомления
        }
    }

    private static PendingIntent alarmHour(Context c, long id) {
        Intent i = new Intent(c, ReminderReceiver.class).setAction(ACTION_SNOOZE).setData(Uri.parse("note://" + id + "/hour"))
                .putExtra("id", id).putExtra("minutes", 60);
        return PendingIntent.getBroadcast(c, (int) id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static String firstLine(String s, String def) {
        int nl = s.indexOf('\n');
        String f = (nl < 0 ? s : s.substring(0, nl)).trim();
        if (f.length() > 80) f = f.substring(0, 80) + "…";
        return f.isEmpty() ? def : f;
    }

    private static String rest(String s) {
        int nl = s.indexOf('\n');
        return nl < 0 ? "" : s.substring(nl + 1).trim();
    }
}
