package com.neondrift.notes;

import java.util.Calendar;

/** Повтор напоминаний. */
final class Repeat {
    private Repeat() {}

    static final int NONE = 0, DAILY = 1, WEEKLY = 2, MONTHLY = 3, YEARLY = 4;
    static final String[] NAMES = {"Не повторять", "Каждый день", "Каждую неделю", "Каждый месяц", "Каждый год"};

    /** Следующее срабатывание строго позже now; для разовых — само время (или 0, если прошло). */
    static long next(long when, int repeat, long now) {
        if (repeat == NONE) return when > now ? when : 0;
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(when);
        int guard = 0;
        while (c.getTimeInMillis() <= now && guard++ < 100_000) {
            switch (repeat) {
                case DAILY: c.add(Calendar.DAY_OF_MONTH, 1); break;
                case WEEKLY: c.add(Calendar.WEEK_OF_YEAR, 1); break;
                case MONTHLY: c.add(Calendar.MONTH, 1); break;
                default: c.add(Calendar.YEAR, 1); break;
            }
        }
        return c.getTimeInMillis();
    }
}
