package com.neondrift.notes;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Будильники сбрасываются при перезагрузке и обновлении — ставим их заново. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        PendingResult pr = goAsync();
        Context app = c.getApplicationContext();
        new Thread(() -> {
            try {
                Reminders.syncAll(app);
                NoteWidget.refreshAll(app);
            } finally {
                pr.finish();
            }
        }).start();
    }
}
