package com.neondrift.notes;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Резервная копия в ZIP: neon-notes.json (заметки, папки, сейф), файлы вложений как есть
 * (зашифрованные остаются зашифрованными) и копия заметок в Markdown — её можно открыть где угодно.
 */
final class Backup {
    private Backup() {}

    static final String JSON = "neon-notes.json";

    static final class Stats {
        int notes, files, added, skipped, lockedSkipped;
    }

    // ================================================================== сохранение

    static Stats export(Context c, OutputStream os) throws IOException {
        Store st = Store.get(c);
        Prefs p = new Prefs(c);
        Stats s = new Stats();
        LinkedHashMap<String, Object> root = new LinkedHashMap<>();
        root.put("app", "Neon Notes");
        root.put("format", 1L);
        root.put("exported", System.currentTimeMillis());
        if (p.vaultSalt() != null) {
            LinkedHashMap<String, Object> v = new LinkedHashMap<>();
            v.put("salt", p.vaultSalt());
            v.put("check", p.vaultCheck());
            root.put("vault", v);
        }
        ArrayList<Object> folders = new ArrayList<>();
        HashMap<Long, String> folderNames = new HashMap<>();
        for (Store.Folder f : st.folders()) {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            m.put("id", f.id);
            m.put("name", f.name);
            m.put("color", (long) f.color);
            m.put("position", (long) f.position);
            folders.add(m);
            folderNames.put(f.id, f.name);
        }
        root.put("folders", folders);
        HashMap<Long, List<Store.Att>> byNote = new HashMap<>();
        for (Store.Att a : st.allAttachments()) byNote.computeIfAbsent(a.note, k -> new ArrayList<>()).add(a);
        ArrayList<Object> notes = new ArrayList<>();
        List<Note> all = st.all();
        for (Note n : all) {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            m.put("title", n.title);
            m.put("body", n.body);
            m.put("color", (long) n.color);
            m.put("folder", n.folder);
            m.put("pinned", n.pinned);
            m.put("archived", n.archived);
            m.put("trashed", n.trashed);
            m.put("locked", n.locked);
            m.put("created", n.created);
            m.put("edited", n.edited);
            m.put("reminder", n.reminder);
            m.put("repeat", (long) n.repeat);
            m.put("fired", n.fired);
            ArrayList<Object> atts = new ArrayList<>();
            for (Store.Att a : byNote.getOrDefault(n.id, new ArrayList<>())) {
                LinkedHashMap<String, Object> am = new LinkedHashMap<>();
                am.put("kind", (long) a.kind);
                am.put("file", a.file);
                am.put("duration", a.duration);
                am.put("created", a.created);
                am.put("w", (long) a.w);
                am.put("h", (long) a.h);
                atts.add(am);
            }
            m.put("attachments", atts);
            notes.add(m);
            s.notes++;
        }
        root.put("notes", notes);

        try (ZipOutputStream zip = new ZipOutputStream(os)) {
            zip.putNextEntry(new ZipEntry(JSON));
            zip.write(Json.write(root).getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
            for (List<Store.Att> list : byNote.values()) {
                for (Store.Att a : list) {
                    File f = Media.file(c, a);
                    if (!f.isFile()) continue;
                    zip.putNextEntry(new ZipEntry("attachments/" + a.file));
                    try (InputStream in = new FileInputStream(f)) {
                        Media.copy(in, zip);
                    }
                    zip.closeEntry();
                    s.files++;
                }
            }
            // читаемая копия: Markdown по папкам (без сейфа и корзины)
            HashSet<String> used = new HashSet<>();
            for (Note n : all) {
                if (n.locked || n.trashed > 0) continue;
                String dir = "markdown/" + (n.archived ? "Архив/" : "")
                        + (n.folder > 0 && folderNames.containsKey(n.folder) ? Note.fileName(folderNames.get(n.folder), "Папка") + "/" : "");
                String base = Note.fileName(n.title.isEmpty() ? firstLine(Md.plain(n.body)) : n.title, "Заметка");
                String name = dir + base + ".md";
                for (int k = 2; used.contains(name.toLowerCase()); k++) name = dir + base + " (" + k + ").md";
                used.add(name.toLowerCase());
                zip.putNextEntry(new ZipEntry(name));
                String md = (n.title.isEmpty() ? "" : "# " + n.title + "\n\n") + n.body + "\n";
                zip.write(md.getBytes(StandardCharsets.UTF_8));
                zip.closeEntry();
            }
        }
        return s;
    }

    private static String firstLine(String s) {
        s = s.trim();
        int nl = s.indexOf('\n');
        return nl < 0 ? s : s.substring(0, nl);
    }

    // ================================================================== восстановление

    /** Прочитанная копия: данные и временная папка с файлами. */
    static final class Plan {
        Map<String, Object> root;
        File dir;
        int notes, locked;
        String vaultSalt, vaultCheck;

        /** Копия зашифрована другим PIN, чем текущий сейф. */
        boolean needsBackupPin(Context c) {
            Prefs p = new Prefs(c);
            return locked > 0 && vaultSalt != null && p.vaultSalt() != null
                    && !(vaultSalt.equals(p.vaultSalt()) && vaultCheck.equals(p.vaultCheck()));
        }

        /** Проверить PIN от копии: ключ или null. */
        byte[] checkPin(String pin) {
            if (vaultSalt == null) return null;
            byte[] k = Vault.derive(pin, Base64.getDecoder().decode(vaultSalt));
            return Vault.CHECK.equals(Vault.open(k, vaultCheck)) ? k : null;
        }

        void cleanup() {
            deleteTree(dir);
        }
    }

    @SuppressWarnings("unchecked")
    static Plan read(Context c, InputStream is) throws IOException {
        Plan plan = new Plan();
        plan.dir = new File(c.getCacheDir(), "import");
        deleteTree(plan.dir);
        plan.dir.mkdirs();
        String json = null;
        try (ZipInputStream zip = new ZipInputStream(is)) {
            ZipEntry e;
            byte[] buf = new byte[64 * 1024];
            while ((e = zip.getNextEntry()) != null) {
                String name = e.getName();
                if (e.isDirectory()) continue;
                if (name.equals(JSON)) {
                    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                    int n;
                    while ((n = zip.read(buf)) > 0) {
                        bos.write(buf, 0, n);
                        if (bos.size() > 200L * 1024 * 1024) throw new IOException("слишком большой файл");
                    }
                    json = bos.toString("UTF-8");
                } else if (name.startsWith("attachments/")) {
                    String file = name.substring("attachments/".length());
                    if (!safeName(file)) continue;
                    try (OutputStream out = new FileOutputStream(new File(plan.dir, file))) {
                        int n;
                        while ((n = zip.read(buf)) > 0) out.write(buf, 0, n);
                    }
                }
            }
        }
        if (json == null) {
            plan.cleanup();
            throw new IOException("Это не резервная копия Neon Notes");
        }
        Object parsed;
        try {
            parsed = Json.parse(json);
        } catch (IllegalArgumentException ex) {
            plan.cleanup();
            throw new IOException("Копия повреждена");
        }
        if (!(parsed instanceof Map)) {
            plan.cleanup();
            throw new IOException("Копия повреждена");
        }
        plan.root = (Map<String, Object>) parsed;
        Object v = plan.root.get("vault");
        if (v instanceof Map) {
            plan.vaultSalt = Json.str((Map<String, Object>) v, "salt", null);
            plan.vaultCheck = Json.str((Map<String, Object>) v, "check", null);
        }
        for (Object o : Json.list(plan.root, "notes")) {
            if (!(o instanceof Map)) continue;
            plan.notes++;
            if (Json.bool((Map<String, Object>) o, "locked")) plan.locked++;
        }
        return plan;
    }

    static boolean safeName(String f) {
        return !f.isEmpty() && !f.contains("/") && !f.contains("\\") && !f.startsWith(".") && f.length() < 120;
    }

    /**
     * Добавить заметки из копии к текущим (дубликаты пропускаются).
     * backupKey и currentKey нужны, только если копия зашифрована другим PIN.
     */
    @SuppressWarnings("unchecked")
    static Stats apply(Context c, Plan plan, byte[] backupKey, byte[] currentKey) {
        Store st = Store.get(c);
        Prefs p = new Prefs(c);
        Stats s = new Stats();
        // сейфа ещё нет — берём сейф из копии (тот же PIN)
        if (plan.locked > 0 && plan.vaultSalt != null && p.vaultSalt() == null) p.setVault(plan.vaultSalt, plan.vaultCheck);
        boolean sameVault = plan.vaultSalt != null && plan.vaultSalt.equals(p.vaultSalt()) && plan.vaultCheck.equals(p.vaultCheck());
        boolean canReseal = backupKey != null && currentKey != null;

        HashMap<Long, Long> folderMap = new HashMap<>();
        for (Object o : Json.list(plan.root, "folders")) {
            if (!(o instanceof Map)) continue;
            Map<String, Object> m = (Map<String, Object>) o;
            String name = Json.str(m, "name", "").trim();
            if (name.isEmpty()) continue;
            folderMap.put(Json.num(m, "id", 0), st.folderByName(name, (int) Json.num(m, "color", 1)));
        }
        for (Object o : Json.list(plan.root, "notes")) {
            if (!(o instanceof Map)) continue;
            Map<String, Object> m = (Map<String, Object>) o;
            Note n = new Note();
            n.title = Json.str(m, "title", "");
            n.body = Json.str(m, "body", "");
            n.color = (int) Json.num(m, "color", 0);
            if (n.color < 0 || n.color >= Note.FILL.length) n.color = 0;
            n.folder = folderMap.getOrDefault(Json.num(m, "folder", 0), 0L);
            n.pinned = Json.bool(m, "pinned");
            n.archived = Json.bool(m, "archived");
            n.trashed = Json.num(m, "trashed", 0);
            n.locked = Json.bool(m, "locked");
            n.created = Json.num(m, "created", System.currentTimeMillis());
            n.edited = Json.num(m, "edited", n.created);
            n.reminder = Json.num(m, "reminder", 0);
            n.repeat = (int) Json.num(m, "repeat", 0);
            if (n.repeat < 0 || n.repeat > Repeat.YEARLY) n.repeat = 0;
            n.fired = Json.bool(m, "fired");
            long now = System.currentTimeMillis();
            if (n.reminder > 0 && n.reminder < now && !n.fired) {
                // старые напоминания из копии не должны звонить все разом
                if (n.repeat != Repeat.NONE) n.reminder = Repeat.next(n.reminder, n.repeat, now);
                else n.fired = true;
            }
            if (st.exists(n.created, n.edited)) {
                s.skipped++;
                continue;
            }
            boolean reseal = false;
            if (n.locked && !sameVault) {
                if (!canReseal) {
                    s.lockedSkipped++;
                    continue;
                }
                String plain = Vault.open(backupKey, n.body);
                if (plain == null) {
                    s.lockedSkipped++;
                    continue;
                }
                n.body = Vault.seal(currentKey, plain);
                reseal = true;
            }
            long id = st.insert(n);
            s.added++;
            for (Object ao : Json.list(m, "attachments")) {
                if (!(ao instanceof Map)) continue;
                Map<String, Object> am = (Map<String, Object>) ao;
                String file = Json.str(am, "file", "");
                File src = new File(plan.dir, file);
                if (!safeName(file) || !src.isFile()) continue;
                Store.Att a = new Store.Att();
                a.note = id;
                a.kind = (int) Json.num(am, "kind", 0);
                a.duration = Json.num(am, "duration", 0);
                a.created = Json.num(am, "created", 0);
                a.w = (int) Json.num(am, "w", 0);
                a.h = (int) Json.num(am, "h", 0);
                boolean sealed = file.endsWith(".nv");
                String ext = file.replace(".nv", "");
                ext = ext.contains(".") ? ext.substring(ext.lastIndexOf('.')) : "";
                try (InputStream in = new FileInputStream(src)) {
                    if (sealed && reseal) {
                        java.io.ByteArrayOutputStream plainBytes = new java.io.ByteArrayOutputStream();
                        if (!Vault.openStream(backupKey, in, plainBytes)) continue;
                        a.file = Media.write(c, new java.io.ByteArrayInputStream(plainBytes.toByteArray()), ext, currentKey);
                    } else {
                        String name = Media.newName(ext) + (sealed ? ".nv" : "");
                        try (OutputStream out = new FileOutputStream(new File(Media.dir(c), name))) {
                            Media.copy(in, out);
                        }
                        a.file = name;
                    }
                    st.addAttachment(a);
                    s.files++;
                } catch (IOException ignored) {
                }
            }
        }
        plan.cleanup();
        Reminders.syncAll(c);
        return s;
    }

    static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] ch = f.listFiles();
        if (ch != null) for (File x : ch) deleteTree(x);
        f.delete();
    }
}
