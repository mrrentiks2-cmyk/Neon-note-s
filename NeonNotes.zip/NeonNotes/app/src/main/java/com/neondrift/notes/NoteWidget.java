package com.neondrift.notes;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.RemoteViews;

/** Виджет «Заметка на экране»: текст и чек-лист, галочки отмечаются прямо на рабочем столе. */
public class NoteWidget extends AppWidgetProvider {
    static final String ACTION_TAP = "com.neondrift.notes.WIDGET_TAP";

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) update(c, m, id);
    }

    @Override
    public void onDeleted(Context c, int[] ids) {
        Prefs p = new Prefs(c);
        for (int id : ids) p.remove("w_" + id);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (!ACTION_TAP.equals(i.getAction())) return;
        long noteId = i.getLongExtra("note", 0);
        int line = i.getIntExtra("line", -1);
        if (noteId == 0) return;
        if (i.getBooleanExtra("check", false) && line >= 0) {
            PendingResult pr = goAsync();
            Context app = c.getApplicationContext();
            new Thread(() -> {
                try {
                    Store st = Store.get(app);
                    Note n = st.get(noteId);
                    if (n != null && !n.locked && n.trashed == 0) {
                        String nb = Md.toggleCheck(n.body, line);
                        if (new Prefs(app).checkedToBottom()) nb = Md.sortChecked(nb);
                        if (!nb.equals(n.body)) {
                            n.body = nb;
                            n.edited = System.currentTimeMillis();
                            st.update(n);
                        }
                    }
                    refresh(app, noteId);
                } finally {
                    pr.finish();
                }
            }).start();
        } else {
            Intent open = new Intent(c, NoteActivity.class).putExtra("id", noteId).putExtra("outside", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            try {
                c.startActivity(open);
            } catch (Exception ignored) {
                // запуск из фона запрещён системой — откроется по нажатию на заголовок
            }
        }
    }

    static void update(Context c, AppWidgetManager m, int id) {
        long noteId = new Prefs(c).widgetNote(id);
        Note n = noteId > 0 ? Store.get(c).get(noteId) : null;
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_note);
        Theme.load(c);
        if (n == null || n.trashed > 0 || n.locked) {
            rv.setTextViewText(R.id.w_title, "Neon Notes");
            rv.setTextViewText(R.id.w_progress, "");
            rv.setViewVisibility(R.id.w_list, View.GONE);
            rv.setViewVisibility(R.id.w_empty, View.VISIBLE);
            rv.setTextViewText(R.id.w_empty, n != null && n.locked ? "Заметка в сейфе — на экране её не показать. Нажмите, чтобы выбрать другую."
                    : "Заметка удалена. Нажмите, чтобы выбрать другую.");
            Intent cfg = new Intent(c, WidgetConfigActivity.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .setData(Uri.parse("widget://config/" + id)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pi = PendingIntent.getActivity(c, id, cfg, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            rv.setOnClickPendingIntent(R.id.w_root, pi);
            rv.setInt(R.id.w_bg, "setColorFilter", Note.fill(0));
            rv.setInt(R.id.w_edge, "setColorFilter", Theme.LINE);
            m.updateAppWidget(id, rv);
            return;
        }
        String title = n.title.trim();
        if (title.isEmpty()) {
            String plain = Md.plain(n.body).trim();
            int nl = plain.indexOf('\n');
            title = nl > 0 ? plain.substring(0, nl) : "Заметка";
        }
        rv.setTextViewText(R.id.w_title, title);
        int[] p = Md.progress(n.body);
        rv.setTextViewText(R.id.w_progress, p[1] > 0 ? p[0] + "/" + p[1] : "");
        rv.setInt(R.id.w_bg, "setColorFilter", Note.fill(n.color));
        rv.setInt(R.id.w_edge, "setColorFilter", n.color == 0 ? Theme.alpha(Theme.ACCENT, 140) : Note.neon(n.color));
        rv.setViewVisibility(R.id.w_list, View.VISIBLE);
        rv.setViewVisibility(R.id.w_empty, View.GONE);

        Intent open = new Intent(c, NoteActivity.class).putExtra("id", n.id).putExtra("outside", true)
                .setData(Uri.parse("widget://open/" + id + "/" + n.id))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent openPi = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.w_head, openPi);
        rv.setOnClickPendingIntent(R.id.w_empty, openPi);

        Intent svc = new Intent(c, WidgetService.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .setData(Uri.parse("widget://list/" + id + "/" + n.id));
        rv.setRemoteAdapter(R.id.w_list, svc);
        rv.setEmptyView(R.id.w_list, R.id.w_empty);
        Intent tap = new Intent(c, NoteWidget.class).setAction(ACTION_TAP);
        PendingIntent tapPi = PendingIntent.getBroadcast(c, id, tap, PendingIntent.FLAG_UPDATE_CURRENT | (android.os.Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0));
        rv.setPendingIntentTemplate(R.id.w_list, tapPi);
        m.updateAppWidget(id, rv);
        m.notifyAppWidgetViewDataChanged(id, R.id.w_list);
    }

    static int[] ids(Context c) {
        return AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, NoteWidget.class));
    }

    /** Обновить виджеты, на которых показана эта заметка. */
    static void refresh(Context c, long noteId) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        Prefs p = new Prefs(c);
        for (int id : ids(c)) if (p.widgetNote(id) == noteId) update(c, m, id);
    }

    static void refreshAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (int id : ids(c)) update(c, m, id);
    }
}
