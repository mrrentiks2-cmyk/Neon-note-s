package com.neondrift.notes;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки приложения. */
final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    int accent() { return sp.getInt("accent", 3); }
    /** 0 — сетка, 1 — список. */
    int view() { return sp.getInt("view", 0); }
    /** 0 — по изменению, 1 — по созданию, 2 — по названию. */
    int sort() { return sp.getInt("sort", 0); }
    int textSize() { return sp.getInt("textSize", 17); }
    int previewLines() { return sp.getInt("previewLines", 8); }
    boolean checkedToBottom() { return sp.getBoolean("checkedToBottom", true); }
    boolean autoPurge() { return sp.getBoolean("autoPurge", true); }
    boolean showTags() { return sp.getBoolean("showTags", true); }
    boolean openPreview() { return sp.getBoolean("openPreview", false); }
    int morningHour() { return sp.getInt("morningHour", 9); }
    /** Через сколько секунд в фоне закрывать сейф: 0 — сразу. */
    int lockTimeout() { return sp.getInt("lockTimeout", 60); }
    String vaultSalt() { return sp.getString("vaultSalt", null); }
    String vaultCheck() { return sp.getString("vaultCheck", null); }
    String bioKey() { return sp.getString("bioKey", null); }
    long lastPurge() { return sp.getLong("lastPurge", 0); }
    long widgetNote(int widgetId) { return sp.getLong("w_" + widgetId, 0); }

    void put(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    void put(String k, int v) { sp.edit().putInt(k, v).apply(); }
    void put(String k, long v) { sp.edit().putLong(k, v).apply(); }
    void put(String k, String v) { sp.edit().putString(k, v).apply(); }
    void remove(String k) { sp.edit().remove(k).apply(); }

    void setVault(String salt, String check) {
        sp.edit().putString("vaultSalt", salt).putString("vaultCheck", check).commit();
    }
}
